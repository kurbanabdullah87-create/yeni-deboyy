import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bell, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ensureNotifyPermission } from "@/lib/alerts";
import {
  loadAppointments,
  saveAppointments,
  scanAppointmentAlerts,
  type Appointment,
} from "@/lib/appointments";
import { pageHead } from "@/lib/work";

export const Route = createFileRoute("/_authenticated/randevular")({
  head: () => pageHead("Randevular", "Saha randevuları ve 10 dakika erken uyarı."),
  component: AppointmentsPage,
});

function AppointmentsPage() {
  const [items, setItems] = useState<Appointment[]>(() => loadAppointments());
  const [customerName, setCustomerName] = useState("");
  const [at, setAt] = useState("");
  const [detail, setDetail] = useState("");

  useEffect(() => {
    const sync = () => setItems(loadAppointments());
    window.addEventListener("saha-appointments", sync);
    window.addEventListener("storage", sync);
    scanAppointmentAlerts();
    return () => {
      window.removeEventListener("saha-appointments", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  async function add() {
    const name = customerName.trim();
    if (!name || !at) {
      toast.error("Müşteri adı ve saat gerekli");
      return;
    }
    const start = new Date(at);
    if (Number.isNaN(start.getTime())) {
      toast.error("Saat okunamadı");
      return;
    }
    await ensureNotifyPermission();
    const next: Appointment = {
      id: crypto.randomUUID(),
      customerName: name,
      at: start.toISOString(),
      detail: detail.trim(),
      alertedAt: null,
    };
    saveAppointments([next, ...loadAppointments()].sort((a, b) => a.at.localeCompare(b.at)));
    setCustomerName("");
    setAt("");
    setDetail("");
    toast.success("Randevu kaydedildi. 10 dakika kala uyarı verilecek.");
  }

  function remove(id: string) {
    saveAppointments(loadAppointments().filter((item) => item.id !== id));
  }

  const upcoming = [...items].sort((a, b) => a.at.localeCompare(b.at));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Randevular</h1>
        <p className="text-sm text-muted-foreground">
          Kayıtlar bu cihazda durur ve internet yokken de 10 dakika kala titreşimli uyarı verir.
        </p>
      </div>
      <form
        className="space-y-3 rounded-2xl border bg-card p-4"
        onSubmit={(e) => {
          e.preventDefault();
          void add();
        }}
      >
        <Input
          aria-label="Müşteri adı"
          placeholder="Müşteri adı"
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
        />
        <Input aria-label="Randevu saati" type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} />
        <Textarea
          aria-label="İş detayı"
          placeholder="İş detayı"
          value={detail}
          onChange={(e) => setDetail(e.target.value)}
        />
        <Button type="submit" className="w-full">
          <Bell />
          Randevu ekle
        </Button>
      </form>
      {upcoming.length === 0 ? (
        <p className="py-8 text-center text-muted-foreground">Henüz randevu yok.</p>
      ) : (
        upcoming.map((item) => {
          const when = new Date(item.at);
          const past = when.getTime() < Date.now();
          return (
            <article key={item.id} className="flex items-start gap-3 rounded-lg border bg-card p-4">
              <div className="min-w-0 flex-1">
                <h2 className="font-semibold">{item.customerName}</h2>
                <p className="text-sm text-muted-foreground">
                  {when.toLocaleString("tr-TR", { dateStyle: "medium", timeStyle: "short" })}
                </p>
                {item.detail && <p className="mt-1 text-sm">{item.detail}</p>}
                <p className="mt-1 text-xs text-muted-foreground">
                  {item.alertedAt ? "10 dk uyarısı verildi" : past ? "Süresi geçti" : "10 dk kala uyarılacak"}
                </p>
              </div>
              <Button variant="ghost" size="icon" aria-label="Randevuyu sil" onClick={() => remove(item.id)}>
                <Trash2 />
              </Button>
            </article>
          );
        })
      )}
    </div>
  );
}
