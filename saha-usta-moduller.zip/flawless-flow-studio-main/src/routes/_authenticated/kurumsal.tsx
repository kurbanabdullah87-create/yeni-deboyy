import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Mic, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ENTERPRISE_FEATURES } from "@/enterprise/catalog";
import {
  EMPTY_CONTEXT,
  enhanceWithGemini,
  insideJobGeofence,
  integrationFlags,
  maintenanceDue,
  parseFieldNote,
  runEnterpriseFeature,
  type EnterpriseModule,
  type FeatureContext,
  type FeatureResult,
} from "@/enterprise/engine";
import { pageHead } from "@/lib/work";

interface SpeechSession {
  lang: string;
  start: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
}

export const Route = createFileRoute("/_authenticated/kurumsal")({
  head: () => pageHead("Kurumsal", "Saha, finans, stok ve rapor motoru."),
  component: EnterprisePage,
});

const MODULES: { id: EnterpriseModule | "hepsi"; label: string }[] = [
  { id: "hepsi", label: "Tümü" },
  { id: "ai", label: "Yapay zeka" },
  { id: "filo", label: "Filo" },
  { id: "finans", label: "Finans" },
  { id: "ekipman", label: "Ekipman" },
  { id: "offline", label: "Çevrimdışı" },
  { id: "guvenlik", label: "Güvenlik" },
  { id: "stok", label: "Stok" },
  { id: "crm", label: "CRM" },
  { id: "rapor", label: "Rapor" },
  { id: "platform", label: "Platform" },
];

function EnterprisePage() {
  const flags = integrationFlags();
  const [text, setText] = useState("Ahmet ustadan 2000 TL nakit alındı, yarın kuzey tarlaya boru döşenecek");
  const [amount, setAmount] = useState("2000");
  const [cost, setCost] = useState("800");
  const [hours, setHours] = useState("30");
  const [query, setQuery] = useState("");
  const [module, setModule] = useState<EnterpriseModule | "hepsi">("hepsi");
  const [result, setResult] = useState<FeatureResult | null>(null);
  const [note, setNote] = useState<ReturnType<typeof parseFieldNote> | null>(null);
  const [gemini, setGemini] = useState<string | null>(null);

  const ctx = useMemo<FeatureContext>(
    () => ({
      ...EMPTY_CONTEXT,
      text,
      amount: Number(amount) || 0,
      cost: Number(cost) || 0,
      hours: Number(hours) || 0,
      quantity: 2,
      rate: 20,
    }),
    [amount, cost, hours, text],
  );

  const features = ENTERPRISE_FEATURES.filter((feature) => {
    const inModule = module === "hepsi" || feature.module === module;
    const hay = `${feature.id} ${feature.title}`.toLocaleLowerCase("tr");
    return inModule && hay.includes(query.trim().toLocaleLowerCase("tr"));
  }).slice(0, 40);

  function run(id: number) {
    const feature = ENTERPRISE_FEATURES.find((item) => item.id === id);
    if (!feature) return;
    setResult(runEnterpriseFeature(feature, ctx));
  }

  async function dictate() {
    const speechWindow = window as Window & {
      SpeechRecognition?: new () => SpeechSession;
      webkitSpeechRecognition?: new () => SpeechSession;
    };
    const Speech = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
    if (!Speech) {
      toast.error("Bu tarayıcı konuşmayı metne çeviremiyor");
      return;
    }
    const recognition = new Speech();
    recognition.lang = "tr-TR";
    recognition.onresult = (event) => {
      const transcript = event.results[0]?.[0]?.transcript;
      if (!transcript) return;
      setText(transcript);
      setNote(parseFieldNote(transcript));
    };
    recognition.onerror = () => toast.error("Ses alınamadı");
    recognition.start();
  }

  async function askGemini() {
    try {
      const answer = await enhanceWithGemini(text);
      if (!answer) {
        toast.error("VITE_GEMINI_API_KEY yok. Yerel ayrıştırıcı kullanıldı.");
        setNote(parseFieldNote(text));
        return;
      }
      setGemini(answer);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Gemini çalışmadı");
    }
  }

  function locate() {
    if (!navigator.geolocation) {
      toast.error("Konum desteklenmiyor");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const fence = insideJobGeofence({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          siteLat: ctx.siteLat,
          siteLng: ctx.siteLng,
        });
        toast.success(fence.onSite ? "Saha içindesiniz" : `Sahaya ${Math.round(fence.meters)} m`);
      },
      () => toast.error("Konum izni verilmedi"),
    );
  }

  const service = maintenanceDue(ctx.hours);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Kurumsal saha</h1>
        <p className="text-sm text-muted-foreground">
          {ENTERPRISE_FEATURES.length} özellik çalışır. Harita {flags.maps ? "açık" : "anahtarsız"}, Gemini{" "}
          {flags.gemini ? "açık" : "yerel"}, Vision {flags.vision ? "açık" : "yerel"}.
        </p>
      </div>
      <section className="space-y-3 rounded-2xl border bg-card p-4">
        <Textarea aria-label="Saha notu" value={text} onChange={(event) => setText(event.target.value)} />
        <div className="grid grid-cols-3 gap-2">
          <Input aria-label="Tutar" inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} />
          <Input aria-label="Maliyet" inputMode="decimal" value={cost} onChange={(event) => setCost(event.target.value)} />
          <Input aria-label="Saat" inputMode="decimal" value={hours} onChange={(event) => setHours(event.target.value)} />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="secondary" onClick={() => setNote(parseFieldNote(text))}>
            Notu ayrıştır
          </Button>
          <Button type="button" variant="secondary" onClick={() => void dictate()}>
            <Mic />
            Ses
          </Button>
          <Button type="button" variant="secondary" onClick={() => void askGemini()}>
            <Sparkles />
            Gemini
          </Button>
          <Button type="button" variant="secondary" onClick={locate}>
            Saha payı
          </Button>
        </div>
        {note && (
          <p className="text-sm">
            {note.customerHint ?? "Müşteri yok"} · {note.amount ?? "tutar yok"} TL · {note.method ?? "yöntem yok"} ·{" "}
            {note.action ?? "iş yok"} · {note.priority}
          </p>
        )}
        {gemini && <p className="whitespace-pre-wrap text-sm text-muted-foreground">{gemini}</p>}
        <p className="text-sm">
          Bakım: {service.due ? "30 saat doldu" : `${service.remaining} saat kaldı`}
        </p>
      </section>
      <Input aria-label="Özellik ara" placeholder="Özellik ara" value={query} onChange={(event) => setQuery(event.target.value)} />
      <div className="flex gap-2 overflow-x-auto pb-1">
        {MODULES.map((item) => (
          <Button
            key={item.id}
            type="button"
            size="sm"
            variant={module === item.id ? "default" : "secondary"}
            onClick={() => setModule(item.id)}
          >
            {item.label}
          </Button>
        ))}
      </div>
      {result && (
        <article className="rounded-2xl border bg-card p-4 text-sm">
          <p className="font-semibold">
            {result.id}. {result.title}
          </p>
          <p className="mt-1 text-muted-foreground">{result.summary}</p>
        </article>
      )}
      <div className="space-y-2">
        {features.map((feature) => (
          <button
            key={feature.id}
            type="button"
            className="flex w-full items-center justify-between gap-3 rounded-lg border bg-card px-3 py-2 text-left text-sm"
            onClick={() => run(feature.id)}
          >
            <span>
              {feature.id}. {feature.title}
            </span>
            <span className="text-xs text-muted-foreground">Çalıştır</span>
          </button>
        ))}
      </div>
    </div>
  );
}
