import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Play, Pause, Check, MapPin, Copy, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { FormDrawer } from "@/components/app/forms/FormDrawer";
import { RecordFields, type Field } from "@/components/app/RecordFields";
import { MediaTools } from "@/components/app/MediaTools";
import { useCustomers } from "@/lib/data";
import { useMe } from "@/hooks/use-me";
import { supabase } from "@/integrations/supabase/client";
import { ensureNotifyPermission } from "@/lib/alerts";
import { persistWrite } from "@/lib/offline";
import {
  useArchiveRecord,
  useRecords,
  useSaveRecord,
  elapsedSeconds,
  hourlyCharge,
  pageHead,
  type Payload,
  type WorkRecord,
} from "@/lib/work";
import { todayISO, formatTL } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/isler")({
  head: () => pageHead("İşler", "İş planı, çalışma süreleri ve saha kayıtları."),
  component: Jobs,
});

const STATUSES = ["Bekliyor", "Devam Ediyor", "Tamamlandı", "Ertelendi"];

function Jobs() {
  const jobs = useRecords("job");
  const templates = useRecords("job_template");
  const saveTemplate = useSaveRecord("job_template");
  const save = useSaveRecord("job");
  const archive = useArchiveRecord();
  const customers = useCustomers();
  const me = useMe();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<WorkRecord>();
  const [form, setForm] = useState<Payload>({});
  const [filter, setFilter] = useState("Tümü");
  const [date, setDate] = useState(todayISO());
  const [expanded, setExpanded] = useState<string>();
  const [now, setNow] = useState(Date.now());
  const [billing, setBilling] = useState(false);
  const [weather, setWeather] = useState("");

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const [members, setMembers] = useState<{ id: string; username: string }[]>([]);
  useEffect(() => {
    supabase
      .from("profiles")
      .select("id,username")
      .then(({ data }) => setMembers(data ?? []));
  }, []);

  const fields: Field[] = [
    { key: "title", label: "İş adı", required: true },
    {
      key: "customer_id",
      label: "Müşteri",
      options: (customers.data ?? []).map((c) => ({ value: c.id, label: c.name })),
    },
    {
      key: "owner_id",
      label: "Görevli",
      options: members.map((m) => ({ value: m.id, label: m.username })),
    },
    { key: "date", label: "Randevu tarihi", type: "date", required: true },
    { key: "address", label: "İş adresi" },
    { key: "hourly_rate", label: "Saatlik ücret (TL)", type: "number" },
    { key: "price", label: "Sabit iş ücreti (TL)", type: "number" },
    { key: "material_cost", label: "Malzeme maliyeti (TL)", type: "number" },
    {
      key: "vat_rate",
      label: "KDV",
      options: [
        { value: "0", label: "Yok" },
        { value: "10", label: "%10" },
        { value: "20", label: "%20" },
      ],
    },
    { key: "notes", label: "İş notu" },
  ];

  function edit(j?: WorkRecord, p?: Payload) {
    setEditing(j);
    setForm(
      j
        ? { ...j.payload, owner_id: j.owner_id }
        : {
            title: "",
            date,
            seconds: 0,
            started_at: null,
            status: "Bekliyor",
            vat_rate: 0,
            owner_id: me.data?.id,
            ...p,
          },
    );
    setOpen(true);
  }

  async function change(j: WorkRecord, p: Payload) {
    await save.mutateAsync({ id: j.id, owner_id: j.owner_id, payload: p });
  }

  async function archiveJob(j: WorkRecord) {
    if (!confirm("Bu iş arşive taşınsın mı?")) return;
    const linked = await supabase
      .from("transactions")
      .select("id")
      .eq("job_record_id", j.id)
      .is("deleted_at", null);
    if (!linked.error) {
      for (const row of linked.data ?? []) {
        await persistWrite("transactions", "delete", { id: row.id });
      }
    }
    await archive(j);
    await qc.invalidateQueries({ queryKey: ["transactions"] });
  }

  async function bill(j: WorkRecord) {
    setBilling(true);
    try {
      const { error } = await supabase.rpc("bill_job", { _job_id: j.id });
      if (error) throw error;
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["work"] }),
        qc.invalidateQueries({ queryKey: ["transactions"] }),
      ]);
      toast.success("İş tamamlandı; borç cariye işlendi.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "İş tamamlanamadı");
    } finally {
      setBilling(false);
    }
  }

  function getWeather() {
    if (!navigator.geolocation) {
      setWeather("Konum desteklenmiyor");
      return;
    }
    setWeather("Hava durumu alınıyor…");
    navigator.geolocation.getCurrentPosition(
      async ({ coords }) => {
        try {
          const r = await fetch(
            `https://api.open-meteo.com/v1/forecast?latitude=${coords.latitude}&longitude=${coords.longitude}&current=temperature_2m,precipitation,wind_speed_10m&timezone=auto`,
          );
          if (!r.ok) throw new Error();
          const w = await r.json();
          setWeather(
            `${w.current.temperature_2m}°C · Yağış ${w.current.precipitation} mm · Rüzgâr ${w.current.wind_speed_10m} km/sa`,
          );
        } catch {
          setWeather("Hava durumu alınamadı");
        }
      },
      () => setWeather("Konum izni verilmedi"),
    );
  }

  const rows = (jobs.data ?? []).filter(
    (j) => (filter === "Tümü" || j.payload.status === filter) && (!date || j.payload.date === date),
  );
  const running = [...(jobs.data ?? [])]
    .filter((j) => j.payload.started_at)
    .sort((a, b) => String(b.payload.started_at).localeCompare(String(a.payload.started_at)));
  const active = running[0];
  const activeSeconds = active ? elapsedSeconds(active.payload, now) : 0;
  const remainMin = active ? Math.ceil((3600 - (Math.floor(activeSeconds) % 3600)) / 60) : 0;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">İşler</h1>
        {me.data?.isUsta && (
          <Button onClick={() => edit()}>
            <Plus />
            İş ekle
          </Button>
        )}
      </div>
      <section className="space-y-2 rounded-2xl border bg-card p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Saatlik yevmiye sayacı
        </p>
        {active ? (
          <>
            <p className="font-semibold">{active.payload.title}</p>
            <p className="num text-4xl">
              {Math.floor(activeSeconds / 3600)}:
              {String(Math.floor(activeSeconds / 60) % 60).padStart(2, "0")}:
              {String(Math.floor(activeSeconds) % 60).padStart(2, "0")}
            </p>
            <p className="text-sm text-muted-foreground">
              Biriken{" "}
              {formatTL(
                Number(active.payload.hourly_rate) > 0
                  ? hourlyCharge(activeSeconds, Number(active.payload.hourly_rate))
                  : Number(active.payload.price ?? 0),
              )}
              {" · "}sonraki uyarı {remainMin} dk
            </p>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">
            Bir işte İşe Başla dediğinizde sayaç açılır. Her tam saatte cihaz titrer ve yevmiye bildirimi gelir.
          </p>
        )}
      </section>
      <div className="flex flex-wrap items-center gap-2">
        <input
          aria-label="İş günü"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="rounded-md border bg-secondary p-2 text-sm"
        />
        <Button variant="ghost" size="sm" onClick={() => setDate("")}>
          Tüm tarihler
        </Button>
        <Button variant="outline" size="sm" onClick={getWeather}>
          Hava durumu
        </Button>
      </div>
      {weather && <p className="text-sm text-muted-foreground">{weather}</p>}
      <select
        aria-label="İş durumu filtresi"
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        className="h-11 w-full rounded-md border bg-secondary px-3"
      >
        {["Tümü", ...STATUSES].map((s) => (
          <option key={s}>{s}</option>
        ))}
      </select>
      {me.data?.isUsta && !!templates.data?.length && (
        <div className="flex flex-wrap gap-2">
          {templates.data.map((t) => (
            <Button
              key={t.id}
              size="sm"
              variant="secondary"
              onClick={() => edit(undefined, t.payload)}
            >
              <Copy />
              {t.payload.title}
            </Button>
          ))}
        </div>
      )}
      {jobs.error && <p className="text-destructive">İşler yüklenemedi.</p>}
      {jobs.isLoading ? (
        <p className="text-muted-foreground">Yükleniyor…</p>
      ) : rows.length === 0 ? (
        <p className="py-8 text-center text-muted-foreground">Bu tarihte iş yok.</p>
      ) : (
        rows.map((j, index) => {
          const p = j.payload;
          const seconds = elapsedSeconds(p, now);
          const customer = customers.data?.find((c) => c.id === p.customer_id);
          const address = String(p.address || customer?.address || "");
          return (
            <article key={j.id} className="space-y-3 rounded-lg border bg-card p-4">
              <div className="flex justify-between gap-2">
                <div className="min-w-0">
                  <h2 className="font-semibold break-words">
                    {index + 1}. {p.title}
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    {customer?.name} · {p.date}
                  </p>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="İş detayları"
                  onClick={() => setExpanded(expanded === j.id ? undefined : j.id)}
                >
                  <ChevronDown />
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <span className={p.status === "Tamamlandı" ? "text-success" : "text-warning"}>
                  {p.status}
                </span>
                <span className="num">
                  {Math.floor(seconds / 3600)}:
                  {String(Math.floor(seconds / 60) % 60).padStart(2, "0")}:
                  {String(Math.floor(seconds) % 60).padStart(2, "0")}
                </span>
              </div>
              {me.data?.isUsta && (
                <>
                  <p className="num text-primary">
                    {formatTL(
                      Number(p.hourly_rate) > 0
                        ? hourlyCharge(seconds, Number(p.hourly_rate))
                        : Number(p.price ?? 0),
                    )}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      disabled={save.isPending || Boolean(p.billed)}
                      onClick={() => {
                        if (!p.started_at) void ensureNotifyPermission();
                        void change(j, {
                          ...p,
                          seconds,
                          started_at: p.started_at ? null : new Date().toISOString(),
                          status: p.started_at ? "Bekliyor" : "Devam Ediyor",
                        });
                      }}
                    >
                      {p.started_at ? <Pause /> : <Play />}
                      {p.started_at ? "Duraklat" : "İşe Başla"}
                    </Button>
                    <Button
                      size="sm"
                      disabled={billing || Boolean(p.billed) || !navigator.onLine}
                      onClick={() => void bill(j)}
                    >
                      <Check />
                      {p.billed ? "Cariye işlendi" : "Bitir ve cariye işle"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={Boolean(p.billed)}
                      onClick={() => edit(j)}
                    >
                      Düzenle
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:bg-destructive/10"
                      onClick={() => void archiveJob(j)}
                    >
                      Sil
                    </Button>
                  </div>
                </>
              )}
              {address && (
                <div className="flex gap-2">
                  <Button asChild size="sm" variant="outline">
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <MapPin />
                      Google
                    </a>
                  </Button>
                  <Button asChild size="sm" variant="outline">
                    <a
                      href={`https://yandex.com/maps/?text=${encodeURIComponent(address)}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <MapPin />
                      Yandex
                    </a>
                  </Button>
                </div>
              )}
              {expanded === j.id && (
                <div className="space-y-3 border-t pt-3">
                  <p className="text-sm break-words">{p.notes}</p>
                  {me.data?.isUsta && (
                    <>
                      <select
                        aria-label="İş durumunu değiştir"
                        className="w-full rounded-md border bg-secondary p-2"
                        disabled={Boolean(p.billed)}
                        value={String(p.status)}
                        onChange={(e) => void change(j, { ...p, status: e.target.value })}
                      >
                        {STATUSES.map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          saveTemplate.mutate({
                            payload: {
                              title: p.title,
                              hourly_rate: p.hourly_rate,
                              price: p.price,
                              material_cost: p.material_cost,
                              vat_rate: p.vat_rate,
                              notes: p.notes,
                            },
                          })
                        }
                      >
                        <Copy />
                        Şablon olarak kaydet
                      </Button>
                    </>
                  )}
                  <MediaTools record={j} readOnly={!me.data?.isUsta} onSave={(p) => change(j, p)} />
                </div>
              )}
            </article>
          );
        })
      )}
      <FormDrawer
        open={open}
        onOpenChange={setOpen}
        title={editing ? "İşi düzenle" : "Yeni iş"}
        busy={save.isPending}
        onSubmit={() => {
          if (!String(form.title ?? "").trim()) return;
          const { owner_id, ...payload } = form;
          save.mutate(
            { id: editing?.id, owner_id: String(owner_id ?? me.data?.id), payload },
            { onSuccess: () => setOpen(false) },
          );
        }}
      >
        <RecordFields fields={fields} value={form} onChange={setForm} />
      </FormDrawer>
    </div>
  );
}
