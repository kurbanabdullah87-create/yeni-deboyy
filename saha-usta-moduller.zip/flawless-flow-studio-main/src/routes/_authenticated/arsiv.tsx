import { createFileRoute } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { RotateCcw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useArchiveActions, useArchived } from "@/lib/data";
import { EXPENSE_LABELS, formatDate, formatTL, type ExpenseCategory } from "@/lib/finance";
import { pageHead, type Payload } from "@/lib/work";

export const Route = createFileRoute("/_authenticated/arsiv")({
  head: () => pageHead("Arşiv", "Silinen iş, gider ve cari kayıtlarını geri yükleyin."),
  component: ArchivePage,
});

const KIND_LABEL: Record<string, string> = {
  job: "İş",
  payroll: "Yevmiye",
  advance: "Avans",
  equipment: "Ekipman",
  maintenance: "Bakım",
  shopping: "Alışveriş",
  job_template: "İş şablonu",
};

function ArchivePage() {
  const customers = useArchived("customers");
  const expenses = useArchived("expenses");
  const transactions = useArchived("transactions");
  const work = useArchived("work_records");
  const actions = useArchiveActions();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Arşiv</h1>
        <p className="text-sm text-muted-foreground">
          Silinen kayıtlar burada durur. Geri yükleyebilir veya kalıcı olarak silebilirsiniz.
        </p>
      </div>
      <Section title="Müşteriler" loading={customers.isLoading} empty={!customers.data?.length}>
        {(customers.data ?? []).map((row) => {
          const item = row as { id: string; name?: string; deleted_at?: string };
          return (
            <ArchiveRow
              key={item.id}
              title={String(item.name ?? "Müşteri")}
              meta={item.deleted_at ? formatDate(item.deleted_at.slice(0, 10)) : ""}
              busy={actions.isPending}
              onRestore={() => actions.mutate({ table: "customers", action: "restore", row })}
              onPurge={() => confirmPurge(() => actions.mutate({ table: "customers", action: "purge", row }))}
            />
          );
        })}
      </Section>
      <Section title="Giderler" loading={expenses.isLoading} empty={!expenses.data?.length}>
        {(expenses.data ?? []).map((row) => {
          const item = row as {
            id: string;
            category?: ExpenseCategory;
            amount?: number;
            description?: string | null;
            deleted_at?: string;
          };
          const label = item.category ? EXPENSE_LABELS[item.category] : "Gider";
          return (
            <ArchiveRow
              key={item.id}
              title={`${label}${item.description ? " · " + item.description : ""}`}
              meta={`${formatTL(Number(item.amount ?? 0))}${item.deleted_at ? " · " + formatDate(item.deleted_at.slice(0, 10)) : ""}`}
              busy={actions.isPending}
              onRestore={() => actions.mutate({ table: "expenses", action: "restore", row })}
              onPurge={() => confirmPurge(() => actions.mutate({ table: "expenses", action: "purge", row }))}
            />
          );
        })}
      </Section>
      <Section title="Cari hareketler" loading={transactions.isLoading} empty={!transactions.data?.length}>
        {(transactions.data ?? []).map((row) => {
          const item = row as {
            id: string;
            description?: string | null;
            kind?: string;
            amount?: number;
            deleted_at?: string;
          };
          return (
            <ArchiveRow
              key={item.id}
              title={item.description || (item.kind === "payment" ? "Tahsilat" : "Borç")}
              meta={`${formatTL(Number(item.amount ?? 0))}${item.deleted_at ? " · " + formatDate(item.deleted_at.slice(0, 10)) : ""}`}
              busy={actions.isPending}
              onRestore={() => actions.mutate({ table: "transactions", action: "restore", row })}
              onPurge={() => confirmPurge(() => actions.mutate({ table: "transactions", action: "purge", row }))}
            />
          );
        })}
      </Section>
      <Section title="İşler ve saha kayıtları" loading={work.isLoading} empty={!work.data?.length}>
        {(work.data ?? []).map((row) => {
          const item = row as {
            id: string;
            kind?: string;
            payload?: Payload;
            deleted_at?: string;
          };
          const payload = item.payload ?? {};
          const title = String(payload.title || payload.name || payload.site || "Kayıt");
          return (
            <ArchiveRow
              key={item.id}
              title={`${KIND_LABEL[item.kind ?? ""] ?? "Kayıt"} · ${title}`}
              meta={item.deleted_at ? formatDate(item.deleted_at.slice(0, 10)) : ""}
              busy={actions.isPending}
              onRestore={() => actions.mutate({ table: "work_records", action: "restore", row })}
              onPurge={() => confirmPurge(() => actions.mutate({ table: "work_records", action: "purge", row }))}
            />
          );
        })}
      </Section>
    </div>
  );
}

function confirmPurge(run: () => void) {
  if (confirm("Bu kayıt kalıcı olarak silinsin mi? Bu işlem geri alınamaz.")) run();
}

function Section({
  title,
  loading,
  empty,
  children,
}: {
  title: string;
  loading: boolean;
  empty: boolean;
  children: ReactNode;
}) {
  return (
    <section className="space-y-2">
      <h2 className="font-semibold">{title}</h2>
      {loading ? (
        <p className="text-sm text-muted-foreground">Yükleniyor…</p>
      ) : empty ? (
        <p className="text-sm text-muted-foreground">Arşivde kayıt yok.</p>
      ) : (
        children
      )}
    </section>
  );
}

function ArchiveRow({
  title,
  meta,
  busy,
  onRestore,
  onPurge,
}: {
  title: string;
  meta: string;
  busy: boolean;
  onRestore: () => void;
  onPurge: () => void;
}) {
  return (
    <article className="flex items-center gap-2 rounded-lg border bg-card p-3">
      <div className="min-w-0 flex-1">
        <p className="truncate font-medium">{title}</p>
        <p className="text-xs text-muted-foreground">{meta}</p>
      </div>
      <Button variant="secondary" size="sm" disabled={busy} onClick={onRestore}>
        <RotateCcw />
        Geri yükle
      </Button>
      <Button variant="ghost" size="sm" className="text-destructive" disabled={busy} onClick={onPurge}>
        <Trash2 />
        Kalıcı sil
      </Button>
    </article>
  );
}
