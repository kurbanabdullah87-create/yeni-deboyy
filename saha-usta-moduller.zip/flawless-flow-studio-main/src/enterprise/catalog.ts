import type { EnterpriseFeatureMeta } from "./engine";

export const ENTERPRISE_FEATURES: EnterpriseFeatureMeta[] = [
  {
    "id": 1,
    "module": "ai",
    "title": "Gemini çok modlu saha notu ayrıştırıcı"
  },
  {
    "id": 2,
    "module": "ai",
    "title": "Sesle iş ve tahsilat doldurma"
  },
  {
    "id": 3,
    "module": "ai",
    "title": "Fotoğraflı iş önceliklendirme"
  },
  {
    "id": 4,
    "module": "ai",
    "title": "Ekipman ve usta eşleştirme"
  },
  {
    "id": 5,
    "module": "ai",
    "title": "Saha kılavuzu soru-cevap"
  },
  {
    "id": 6,
    "module": "ai",
    "title": "Fiş ve fatura okuma"
  },
  {
    "id": 7,
    "module": "ai",
    "title": "İş süresi tahmini"
  },
  {
    "id": 8,
    "module": "ai",
    "title": "Müşteri durum mesajı üretimi"
  },
  {
    "id": 9,
    "module": "ai",
    "title": "İş öncesi risk listesi"
  },
  {
    "id": 10,
    "module": "ai",
    "title": "Sesle eller serbest komut"
  },
  {
    "id": 11,
    "module": "ai",
    "title": "prompt önbelleği"
  },
  {
    "id": 12,
    "module": "ai",
    "title": "jeton maliyeti"
  },
  {
    "id": 13,
    "module": "ai",
    "title": "yerel yedek çözümleme"
  },
  {
    "id": 14,
    "module": "ai",
    "title": "çok turlu bağlam"
  },
  {
    "id": 15,
    "module": "ai",
    "title": "saha günlüğü çevirisi"
  },
  {
    "id": 16,
    "module": "ai",
    "title": "duygu analizi"
  },
  {
    "id": 17,
    "module": "ai",
    "title": "ihtilaf metni"
  },
  {
    "id": 18,
    "module": "ai",
    "title": "sözlü onay"
  },
  {
    "id": 19,
    "module": "ai",
    "title": "garanti talebi"
  },
  {
    "id": 20,
    "module": "ai",
    "title": "vardiya devir özeti"
  },
  {
    "id": 21,
    "module": "ai",
    "title": "kılavuz parçalama"
  },
  {
    "id": 22,
    "module": "ai",
    "title": "geçmiş iş araması"
  },
  {
    "id": 23,
    "module": "ai",
    "title": "vergi metni"
  },
  {
    "id": 24,
    "module": "ai",
    "title": "nakit darboğaz uyarısı"
  },
  {
    "id": 25,
    "module": "ai",
    "title": "sözleşme maddesi"
  },
  {
    "id": 26,
    "module": "ai",
    "title": "fiyat önerisi"
  },
  {
    "id": 27,
    "module": "ai",
    "title": "güvenlik brifingi"
  },
  {
    "id": 28,
    "module": "ai",
    "title": "gider sınıflama"
  },
  {
    "id": 29,
    "module": "ai",
    "title": "stok tükenme uyarısı"
  },
  {
    "id": 30,
    "module": "ai",
    "title": "yorum isteği"
  },
  {
    "id": 31,
    "module": "ai",
    "title": "bildirim metni"
  },
  {
    "id": 32,
    "module": "ai",
    "title": "çakışma önerisi"
  },
  {
    "id": 33,
    "module": "ai",
    "title": "performans yazısı"
  },
  {
    "id": 34,
    "module": "ai",
    "title": "eğitim kartı"
  },
  {
    "id": 35,
    "module": "ai",
    "title": "sipariş e-postası"
  },
  {
    "id": 36,
    "module": "ai",
    "title": "feragat metni"
  },
  {
    "id": 37,
    "module": "ai",
    "title": "fotoğraf etiketi"
  },
  {
    "id": 38,
    "module": "ai",
    "title": "aday puanı"
  },
  {
    "id": 39,
    "module": "ai",
    "title": "garanti bitişi"
  },
  {
    "id": 40,
    "module": "ai",
    "title": "pazarlama cümlesi"
  },
  {
    "id": 41,
    "module": "ai",
    "title": "iletişim özeti"
  },
  {
    "id": 42,
    "module": "ai",
    "title": "delil paketi"
  },
  {
    "id": 43,
    "module": "ai",
    "title": "arıza açıklaması"
  },
  {
    "id": 44,
    "module": "ai",
    "title": "sayım asistanı"
  },
  {
    "id": 45,
    "module": "ai",
    "title": "vergi indirimi"
  },
  {
    "id": 46,
    "module": "ai",
    "title": "taşeron değerlendirme"
  },
  {
    "id": 47,
    "module": "ai",
    "title": "risk planı"
  },
  {
    "id": 48,
    "module": "ai",
    "title": "amortisman yazısı"
  },
  {
    "id": 49,
    "module": "ai",
    "title": "iş ilanı"
  },
  {
    "id": 50,
    "module": "ai",
    "title": "ayrılma riski"
  },
  {
    "id": 51,
    "module": "ai",
    "title": "zimmet kaydı"
  },
  {
    "id": 52,
    "module": "ai",
    "title": "tedarik fiyatı"
  },
  {
    "id": 53,
    "module": "ai",
    "title": "hibe taraması"
  },
  {
    "id": 54,
    "module": "ai",
    "title": "denetim dosyası"
  },
  {
    "id": 55,
    "module": "ai",
    "title": "sigorta anlatısı"
  },
  {
    "id": 56,
    "module": "ai",
    "title": "tahsilat planı"
  },
  {
    "id": 57,
    "module": "ai",
    "title": "olay kaydı"
  },
  {
    "id": 58,
    "module": "ai",
    "title": "çevre etkisi"
  },
  {
    "id": 59,
    "module": "ai",
    "title": "enerji denetimi"
  },
  {
    "id": 60,
    "module": "ai",
    "title": "politika metni"
  },
  {
    "id": 61,
    "module": "ai",
    "title": "kurul özeti"
  },
  {
    "id": 62,
    "module": "ai",
    "title": "yatırımcı notu"
  },
  {
    "id": 63,
    "module": "ai",
    "title": "ortaklık taslağı"
  },
  {
    "id": 64,
    "module": "ai",
    "title": "itibar notu"
  },
  {
    "id": 65,
    "module": "ai",
    "title": "pazar özeti"
  },
  {
    "id": 66,
    "module": "ai",
    "title": "rakip fiyat"
  },
  {
    "id": 67,
    "module": "ai",
    "title": "paket önerisi"
  },
  {
    "id": 68,
    "module": "ai",
    "title": "sadakat kademesi"
  },
  {
    "id": 69,
    "module": "ai",
    "title": "yönlendirme kuralı"
  },
  {
    "id": 70,
    "module": "ai",
    "title": "tutundurma teklifi"
  },
  {
    "id": 71,
    "module": "ai",
    "title": "geri bildirim özeti"
  },
  {
    "id": 72,
    "module": "ai",
    "title": "özellik isteği"
  },
  {
    "id": 73,
    "module": "ai",
    "title": "sürüm notu"
  },
  {
    "id": 74,
    "module": "ai",
    "title": "geliştirici notu"
  },
  {
    "id": 75,
    "module": "ai",
    "title": "entegrasyon sağlığı"
  },
  {
    "id": 76,
    "module": "ai",
    "title": "yama planı"
  },
  {
    "id": 77,
    "module": "ai",
    "title": "uyum listesi"
  },
  {
    "id": 78,
    "module": "ai",
    "title": "gizlilik etkisi"
  },
  {
    "id": 79,
    "module": "ai",
    "title": "felaket planı"
  },
  {
    "id": 80,
    "module": "ai",
    "title": "altyapı maliyeti"
  },
  {
    "id": 81,
    "module": "ai",
    "title": "sorgu planı"
  },
  {
    "id": 82,
    "module": "ai",
    "title": "önbellek oranı"
  },
  {
    "id": 83,
    "module": "ai",
    "title": "gecikme"
  },
  {
    "id": 84,
    "module": "ai",
    "title": "paket boyutu"
  },
  {
    "id": 85,
    "module": "ai",
    "title": "bellek"
  },
  {
    "id": 86,
    "module": "ai",
    "title": "ağ tasarrufu"
  },
  {
    "id": 87,
    "module": "ai",
    "title": "pil tasarrufu"
  },
  {
    "id": 88,
    "module": "ai",
    "title": "depolama sıkıştırma"
  },
  {
    "id": 89,
    "module": "ai",
    "title": "eşitleme çatışması"
  },
  {
    "id": 90,
    "module": "ai",
    "title": "titreşim deseni"
  },
  {
    "id": 91,
    "module": "ai",
    "title": "konum izleyici"
  },
  {
    "id": 92,
    "module": "ai",
    "title": "ağ tipi"
  },
  {
    "id": 93,
    "module": "ai",
    "title": "pil durumu"
  },
  {
    "id": 94,
    "module": "ai",
    "title": "pano"
  },
  {
    "id": 95,
    "module": "ai",
    "title": "uyanık tutma"
  },
  {
    "id": 96,
    "module": "ai",
    "title": "tam ekran"
  },
  {
    "id": 97,
    "module": "ai",
    "title": "paylaşım"
  },
  {
    "id": 98,
    "module": "ai",
    "title": "bildirim rozeti"
  },
  {
    "id": 99,
    "module": "ai",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 100,
    "module": "ai",
    "title": "tutar yuvarlama"
  },
  {
    "id": 101,
    "module": "filo",
    "title": "Canlı saha konum panosu"
  },
  {
    "id": 102,
    "module": "filo",
    "title": "Çok duraklı rota sıralama"
  },
  {
    "id": 103,
    "module": "filo",
    "title": "50 metre saha giriş-çıkış"
  },
  {
    "id": 104,
    "module": "filo",
    "title": "30-45-60 dakika hizmet alanı"
  },
  {
    "id": 105,
    "module": "filo",
    "title": "Eğim ve arazi profili"
  },
  {
    "id": 106,
    "module": "filo",
    "title": "Sokak görünümü ön izleme"
  },
  {
    "id": 107,
    "module": "filo",
    "title": "Çevrimdışı harita bağlantısı"
  },
  {
    "id": 108,
    "module": "filo",
    "title": "Yakıt ve geçiş maliyeti"
  },
  {
    "id": 109,
    "module": "filo",
    "title": "Müşteri yoğunluk haritası"
  },
  {
    "id": 110,
    "module": "filo",
    "title": "Bölge iş kümeleme"
  },
  {
    "id": 111,
    "module": "filo",
    "title": "hız sınırı uyarısı"
  },
  {
    "id": 112,
    "module": "filo",
    "title": "rölanti süresi"
  },
  {
    "id": 113,
    "module": "filo",
    "title": "iz kaydı"
  },
  {
    "id": 114,
    "module": "filo",
    "title": "rota sapması"
  },
  {
    "id": 115,
    "module": "filo",
    "title": "adres düzeltme"
  },
  {
    "id": 116,
    "module": "filo",
    "title": "varış süresi"
  },
  {
    "id": 117,
    "module": "filo",
    "title": "en yakın usta"
  },
  {
    "id": 118,
    "module": "filo",
    "title": "konvoy"
  },
  {
    "id": 119,
    "module": "filo",
    "title": "acil konum"
  },
  {
    "id": 120,
    "module": "filo",
    "title": "park noktası"
  },
  {
    "id": 121,
    "module": "filo",
    "title": "hava katmanı"
  },
  {
    "id": 122,
    "module": "filo",
    "title": "eğim katmanı"
  },
  {
    "id": 123,
    "module": "filo",
    "title": "saha fotoğraf konumu"
  },
  {
    "id": 124,
    "module": "filo",
    "title": "özel iğne"
  },
  {
    "id": 125,
    "module": "filo",
    "title": "KML dışa aktarma"
  },
  {
    "id": 126,
    "module": "filo",
    "title": "çok depo"
  },
  {
    "id": 127,
    "module": "filo",
    "title": "akaryakıt istasyonu"
  },
  {
    "id": 128,
    "module": "filo",
    "title": "şarj noktası"
  },
  {
    "id": 129,
    "module": "filo",
    "title": "gabari uyarısı"
  },
  {
    "id": 130,
    "module": "filo",
    "title": "köprü ağırlığı"
  },
  {
    "id": 131,
    "module": "filo",
    "title": "tek yön"
  },
  {
    "id": 132,
    "module": "filo",
    "title": "yasak bölge"
  },
  {
    "id": 133,
    "module": "filo",
    "title": "feribot saati"
  },
  {
    "id": 134,
    "module": "filo",
    "title": "toprak yol"
  },
  {
    "id": 135,
    "module": "filo",
    "title": "gece modu"
  },
  {
    "id": 136,
    "module": "filo",
    "title": "uydu görüntüsü"
  },
  {
    "id": 137,
    "module": "filo",
    "title": "trafik ısısı"
  },
  {
    "id": 138,
    "module": "filo",
    "title": "sel riski"
  },
  {
    "id": 139,
    "module": "filo",
    "title": "rüzgar yönü"
  },
  {
    "id": 140,
    "module": "filo",
    "title": "ilaç sürüklenmesi"
  },
  {
    "id": 141,
    "module": "filo",
    "title": "drone hattı"
  },
  {
    "id": 142,
    "module": "filo",
    "title": "gölge analizi"
  },
  {
    "id": 143,
    "module": "filo",
    "title": "sulama hattı"
  },
  {
    "id": 144,
    "module": "filo",
    "title": "kablo hendeği"
  },
  {
    "id": 145,
    "module": "filo",
    "title": "kuyu verimi"
  },
  {
    "id": 146,
    "module": "filo",
    "title": "otlatma dönüşü"
  },
  {
    "id": 147,
    "module": "filo",
    "title": "çit denetimi"
  },
  {
    "id": 148,
    "module": "filo",
    "title": "zararlı odağı"
  },
  {
    "id": 149,
    "module": "filo",
    "title": "gübre bölgesi"
  },
  {
    "id": 150,
    "module": "filo",
    "title": "hasat ısısı"
  },
  {
    "id": 151,
    "module": "filo",
    "title": "sera bölgesi"
  },
  {
    "id": 152,
    "module": "filo",
    "title": "soğuk oda"
  },
  {
    "id": 153,
    "module": "filo",
    "title": "kovan"
  },
  {
    "id": 154,
    "module": "filo",
    "title": "orman envanteri"
  },
  {
    "id": 155,
    "module": "filo",
    "title": "erozyon"
  },
  {
    "id": 156,
    "module": "filo",
    "title": "havza"
  },
  {
    "id": 157,
    "module": "filo",
    "title": "yaban geçişi"
  },
  {
    "id": 158,
    "module": "filo",
    "title": "heyelan"
  },
  {
    "id": 159,
    "module": "filo",
    "title": "yeraltı suyu"
  },
  {
    "id": 160,
    "module": "filo",
    "title": "gürültü"
  },
  {
    "id": 161,
    "module": "filo",
    "title": "hava kalitesi"
  },
  {
    "id": 162,
    "module": "filo",
    "title": "kaçak döküm"
  },
  {
    "id": 163,
    "module": "filo",
    "title": "kirlenme"
  },
  {
    "id": 164,
    "module": "filo",
    "title": "sıkışma"
  },
  {
    "id": 165,
    "module": "filo",
    "title": "hastalık yayılımı"
  },
  {
    "id": 166,
    "module": "filo",
    "title": "don riski"
  },
  {
    "id": 167,
    "module": "filo",
    "title": "dolu alanı"
  },
  {
    "id": 168,
    "module": "filo",
    "title": "kuraklık"
  },
  {
    "id": 169,
    "module": "filo",
    "title": "mera kapasitesi"
  },
  {
    "id": 170,
    "module": "filo",
    "title": "karbon"
  },
  {
    "id": 171,
    "module": "filo",
    "title": "biyoçeşitlilik"
  },
  {
    "id": 172,
    "module": "filo",
    "title": "yenilenebilir potansiyel"
  },
  {
    "id": 173,
    "module": "filo",
    "title": "mikro iklim"
  },
  {
    "id": 174,
    "module": "filo",
    "title": "sis"
  },
  {
    "id": 175,
    "module": "filo",
    "title": "buz"
  },
  {
    "id": 176,
    "module": "filo",
    "title": "çamur"
  },
  {
    "id": 177,
    "module": "filo",
    "title": "toz"
  },
  {
    "id": 178,
    "module": "filo",
    "title": "kül"
  },
  {
    "id": 179,
    "module": "filo",
    "title": "tahliye"
  },
  {
    "id": 180,
    "module": "filo",
    "title": "deprem yarıçapı"
  },
  {
    "id": 181,
    "module": "filo",
    "title": "yangın çevresi"
  },
  {
    "id": 182,
    "module": "filo",
    "title": "taşkın"
  },
  {
    "id": 183,
    "module": "filo",
    "title": "çığ"
  },
  {
    "id": 184,
    "module": "filo",
    "title": "obruk"
  },
  {
    "id": 185,
    "module": "filo",
    "title": "kıyı erozyonu"
  },
  {
    "id": 186,
    "module": "filo",
    "title": "gelgit"
  },
  {
    "id": 187,
    "module": "filo",
    "title": "nehir seviyesi"
  },
  {
    "id": 188,
    "module": "filo",
    "title": "rezervuar"
  },
  {
    "id": 189,
    "module": "filo",
    "title": "kanal debisi"
  },
  {
    "id": 190,
    "module": "filo",
    "title": "baraj sızıntısı"
  },
  {
    "id": 191,
    "module": "filo",
    "title": "set"
  },
  {
    "id": 192,
    "module": "filo",
    "title": "drenaj"
  },
  {
    "id": 193,
    "module": "filo",
    "title": "foseptik"
  },
  {
    "id": 194,
    "module": "filo",
    "title": "direk envanteri"
  },
  {
    "id": 195,
    "module": "filo",
    "title": "boru hattı"
  },
  {
    "id": 196,
    "module": "filo",
    "title": "fiber"
  },
  {
    "id": 197,
    "module": "filo",
    "title": "kapsama gölgesi"
  },
  {
    "id": 198,
    "module": "filo",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 199,
    "module": "filo",
    "title": "tutar yuvarlama"
  },
  {
    "id": 200,
    "module": "filo",
    "title": "boş girdi reddi"
  },
  {
    "id": 201,
    "module": "finans",
    "title": "Çift taraflı yevmiye fişi"
  },
  {
    "id": 202,
    "module": "finans",
    "title": "KDV ve stopaj hesabı"
  },
  {
    "id": 203,
    "module": "finans",
    "title": "Döviz çevrimi"
  },
  {
    "id": 204,
    "module": "finans",
    "title": "30-60-90 gün nakit görünümü"
  },
  {
    "id": 205,
    "module": "finans",
    "title": "Borç yaşlandırma"
  },
  {
    "id": 206,
    "module": "finans",
    "title": "Gider fişi sınıflama"
  },
  {
    "id": 207,
    "module": "finans",
    "title": "Yevmiye ve mesai hesabı"
  },
  {
    "id": 208,
    "module": "finans",
    "title": "İş kârlılığı"
  },
  {
    "id": 209,
    "module": "finans",
    "title": "Hakediş takibi"
  },
  {
    "id": 210,
    "module": "finans",
    "title": "IBAN makbuz toplamı"
  },
  {
    "id": 211,
    "module": "finans",
    "title": "banka ekstresi eşleme"
  },
  {
    "id": 212,
    "module": "finans",
    "title": "kasa"
  },
  {
    "id": 213,
    "module": "finans",
    "title": "komisyon oranı"
  },
  {
    "id": 214,
    "module": "finans",
    "title": "temettü"
  },
  {
    "id": 215,
    "module": "finans",
    "title": "amortisman planı"
  },
  {
    "id": 216,
    "module": "finans",
    "title": "kredi taksit"
  },
  {
    "id": 217,
    "module": "finans",
    "title": "garanti karşılığı"
  },
  {
    "id": 218,
    "module": "finans",
    "title": "şüpheli alacak"
  },
  {
    "id": 219,
    "module": "finans",
    "title": "şirket içi virman"
  },
  {
    "id": 220,
    "module": "finans",
    "title": "rotatif limit"
  },
  {
    "id": 221,
    "module": "finans",
    "title": "kasa fişi"
  },
  {
    "id": 222,
    "module": "finans",
    "title": "damga vergisi"
  },
  {
    "id": 223,
    "module": "finans",
    "title": "stopaj bildirimi"
  },
  {
    "id": 224,
    "module": "finans",
    "title": "bilanço"
  },
  {
    "id": 225,
    "module": "finans",
    "title": "gelir tablosu"
  },
  {
    "id": 226,
    "module": "finans",
    "title": "mizan"
  },
  {
    "id": 227,
    "module": "finans",
    "title": "maliyet merkezi"
  },
  {
    "id": 228,
    "module": "finans",
    "title": "bütçe sapması"
  },
  {
    "id": 229,
    "module": "finans",
    "title": "başabaş"
  },
  {
    "id": 230,
    "module": "finans",
    "title": "yatırım getirisi"
  },
  {
    "id": 231,
    "module": "finans",
    "title": "likidite"
  },
  {
    "id": 232,
    "module": "finans",
    "title": "borç ödeme gücü"
  },
  {
    "id": 233,
    "module": "finans",
    "title": "işletme sermayesi"
  },
  {
    "id": 234,
    "module": "finans",
    "title": "stok devir"
  },
  {
    "id": 235,
    "module": "finans",
    "title": "alacak devir"
  },
  {
    "id": 236,
    "module": "finans",
    "title": "nakit döngüsü"
  },
  {
    "id": 237,
    "module": "finans",
    "title": "FAVÖK"
  },
  {
    "id": 238,
    "module": "finans",
    "title": "serbest nakit"
  },
  {
    "id": 239,
    "module": "finans",
    "title": "mali skor"
  },
  {
    "id": 240,
    "module": "finans",
    "title": "mükerrer ödeme"
  },
  {
    "id": 241,
    "module": "finans",
    "title": "çift onay"
  },
  {
    "id": 242,
    "module": "finans",
    "title": "satınalma eşleme"
  },
  {
    "id": 243,
    "module": "finans",
    "title": "cari limit"
  },
  {
    "id": 244,
    "module": "finans",
    "title": "iskonto"
  },
  {
    "id": 245,
    "module": "finans",
    "title": "prim"
  },
  {
    "id": 246,
    "module": "finans",
    "title": "ikramiye"
  },
  {
    "id": 247,
    "module": "finans",
    "title": "kıdem karşılığı"
  },
  {
    "id": 248,
    "module": "finans",
    "title": "izin tahakkuku"
  },
  {
    "id": 249,
    "module": "finans",
    "title": "araç km"
  },
  {
    "id": 250,
    "module": "finans",
    "title": "kira artışı"
  },
  {
    "id": 251,
    "module": "finans",
    "title": "abonelik"
  },
  {
    "id": 252,
    "module": "finans",
    "title": "hukuk gideri"
  },
  {
    "id": 253,
    "module": "finans",
    "title": "hibe kullanımı"
  },
  {
    "id": 254,
    "module": "finans",
    "title": "gümrük"
  },
  {
    "id": 255,
    "module": "finans",
    "title": "navlun"
  },
  {
    "id": 256,
    "module": "finans",
    "title": "fire değeri"
  },
  {
    "id": 257,
    "module": "finans",
    "title": "iade"
  },
  {
    "id": 258,
    "module": "finans",
    "title": "eğitim yatırımı"
  },
  {
    "id": 259,
    "module": "finans",
    "title": "personel borcu"
  },
  {
    "id": 260,
    "module": "finans",
    "title": "avans mahsup"
  },
  {
    "id": 261,
    "module": "finans",
    "title": "icra kesintisi"
  },
  {
    "id": 262,
    "module": "finans",
    "title": "sendika aidatı"
  },
  {
    "id": 263,
    "module": "finans",
    "title": "BES"
  },
  {
    "id": 264,
    "module": "finans",
    "title": "yemek kartı"
  },
  {
    "id": 265,
    "module": "finans",
    "title": "yol yardımı"
  },
  {
    "id": 266,
    "module": "finans",
    "title": "telefon"
  },
  {
    "id": 267,
    "module": "finans",
    "title": "koruyucu donanım"
  },
  {
    "id": 268,
    "module": "finans",
    "title": "makine yenileme fonu"
  },
  {
    "id": 269,
    "module": "finans",
    "title": "acil rezerv"
  },
  {
    "id": 270,
    "module": "finans",
    "title": "kurumlar vergisi taksiti"
  },
  {
    "id": 271,
    "module": "finans",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 272,
    "module": "finans",
    "title": "tutar yuvarlama"
  },
  {
    "id": 273,
    "module": "finans",
    "title": "boş girdi reddi"
  },
  {
    "id": 274,
    "module": "finans",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 275,
    "module": "finans",
    "title": "sonuç özeti"
  },
  {
    "id": 276,
    "module": "finans",
    "title": "Türkçe biçim"
  },
  {
    "id": 277,
    "module": "finans",
    "title": "saat dilimi damgası"
  },
  {
    "id": 278,
    "module": "finans",
    "title": "yetki reddi"
  },
  {
    "id": 279,
    "module": "finans",
    "title": "kota kontrolü"
  },
  {
    "id": 280,
    "module": "finans",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 281,
    "module": "finans",
    "title": "hata mesajı"
  },
  {
    "id": 282,
    "module": "finans",
    "title": "ölçü birimi"
  },
  {
    "id": 283,
    "module": "finans",
    "title": "eşik uyarısı"
  },
  {
    "id": 284,
    "module": "finans",
    "title": "denetim satırı"
  },
  {
    "id": 285,
    "module": "finans",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 286,
    "module": "finans",
    "title": "toplam"
  },
  {
    "id": 287,
    "module": "finans",
    "title": "ortalama"
  },
  {
    "id": 288,
    "module": "finans",
    "title": "sapma"
  },
  {
    "id": 289,
    "module": "finans",
    "title": "medyan"
  },
  {
    "id": 290,
    "module": "finans",
    "title": "üst sınır"
  },
  {
    "id": 291,
    "module": "finans",
    "title": "alt sınır"
  },
  {
    "id": 292,
    "module": "finans",
    "title": "hedef farkı"
  },
  {
    "id": 293,
    "module": "finans",
    "title": "trend"
  },
  {
    "id": 294,
    "module": "finans",
    "title": "eşik aşımı"
  },
  {
    "id": 295,
    "module": "finans",
    "title": "kuyruk süresi"
  },
  {
    "id": 296,
    "module": "finans",
    "title": "öncelik puanı"
  },
  {
    "id": 297,
    "module": "finans",
    "title": "birim maliyet"
  },
  {
    "id": 298,
    "module": "finans",
    "title": "adet kontrolü"
  },
  {
    "id": 299,
    "module": "finans",
    "title": "saatlik hız"
  },
  {
    "id": 300,
    "module": "finans",
    "title": "günlük tempo"
  },
  {
    "id": 301,
    "module": "ekipman",
    "title": "30 saat bakım uyarısı"
  },
  {
    "id": 302,
    "module": "ekipman",
    "title": "Ekipman sayaç özeti"
  },
  {
    "id": 303,
    "module": "ekipman",
    "title": "Kalan ömür tahmini"
  },
  {
    "id": 304,
    "module": "ekipman",
    "title": "Makine defteri"
  },
  {
    "id": 305,
    "module": "ekipman",
    "title": "Yedek parça sayımı"
  },
  {
    "id": 306,
    "module": "ekipman",
    "title": "Zimmet teslimi"
  },
  {
    "id": 307,
    "module": "ekipman",
    "title": "Garanti bitiş kontrolü"
  },
  {
    "id": 308,
    "module": "ekipman",
    "title": "Saatlik yakıt denetimi"
  },
  {
    "id": 309,
    "module": "ekipman",
    "title": "Arıza çağrısı"
  },
  {
    "id": 310,
    "module": "ekipman",
    "title": "Onar veya değiştir"
  },
  {
    "id": 311,
    "module": "ekipman",
    "title": "hidrolik basınç"
  },
  {
    "id": 312,
    "module": "ekipman",
    "title": "lastik basıncı"
  },
  {
    "id": 313,
    "module": "ekipman",
    "title": "yağ ömrü"
  },
  {
    "id": 314,
    "module": "ekipman",
    "title": "hararet"
  },
  {
    "id": 315,
    "module": "ekipman",
    "title": "şarj voltajı"
  },
  {
    "id": 316,
    "module": "ekipman",
    "title": "marş akımı"
  },
  {
    "id": 317,
    "module": "ekipman",
    "title": "hava filtresi"
  },
  {
    "id": 318,
    "module": "ekipman",
    "title": "egzoz ısısı"
  },
  {
    "id": 319,
    "module": "ekipman",
    "title": "turbo"
  },
  {
    "id": 320,
    "module": "ekipman",
    "title": "şanzıman ısısı"
  },
  {
    "id": 321,
    "module": "ekipman",
    "title": "balata"
  },
  {
    "id": 322,
    "module": "ekipman",
    "title": "akü sağlığı"
  },
  {
    "id": 323,
    "module": "ekipman",
    "title": "enjektör"
  },
  {
    "id": 324,
    "module": "ekipman",
    "title": "kızdırma bujisi"
  },
  {
    "id": 325,
    "module": "ekipman",
    "title": "fan rolesi"
  },
  {
    "id": 326,
    "module": "ekipman",
    "title": "ateşleme"
  },
  {
    "id": 327,
    "module": "ekipman",
    "title": "kam mili"
  },
  {
    "id": 328,
    "module": "ekipman",
    "title": "titreşim"
  },
  {
    "id": 329,
    "module": "ekipman",
    "title": "yağ pompası"
  },
  {
    "id": 330,
    "module": "ekipman",
    "title": "devirdaim"
  },
  {
    "id": 331,
    "module": "ekipman",
    "title": "yakıt filtresi"
  },
  {
    "id": 332,
    "module": "ekipman",
    "title": "keçe kaçağı"
  },
  {
    "id": 333,
    "module": "ekipman",
    "title": "kuyruk mili"
  },
  {
    "id": 334,
    "module": "ekipman",
    "title": "diferansiyel"
  },
  {
    "id": 335,
    "module": "ekipman",
    "title": "aks yükü"
  },
  {
    "id": 336,
    "module": "ekipman",
    "title": "rölanti oranı"
  },
  {
    "id": 337,
    "module": "ekipman",
    "title": "soğuk çalıştırma"
  },
  {
    "id": 338,
    "module": "ekipman",
    "title": "toz yutma"
  },
  {
    "id": 339,
    "module": "ekipman",
    "title": "termal kamera"
  },
  {
    "id": 340,
    "module": "ekipman",
    "title": "yağ analizi"
  },
  {
    "id": 341,
    "module": "ekipman",
    "title": "kayış hizası"
  },
  {
    "id": 342,
    "module": "ekipman",
    "title": "rulman ısısı"
  },
  {
    "id": 343,
    "module": "ekipman",
    "title": "zincir gergisi"
  },
  {
    "id": 344,
    "module": "ekipman",
    "title": "kavrama kalınlığı"
  },
  {
    "id": 345,
    "module": "ekipman",
    "title": "şaft boşluğu"
  },
  {
    "id": 346,
    "module": "ekipman",
    "title": "vinç halatı"
  },
  {
    "id": 347,
    "module": "ekipman",
    "title": "bom açısı"
  },
  {
    "id": 348,
    "module": "ekipman",
    "title": "kova diş"
  },
  {
    "id": 349,
    "module": "ekipman",
    "title": "palet gergisi"
  },
  {
    "id": 350,
    "module": "ekipman",
    "title": "kırıcı vuruş"
  },
  {
    "id": 351,
    "module": "ekipman",
    "title": "burgu tork"
  },
  {
    "id": 352,
    "module": "ekipman",
    "title": "bıçak keskinliği"
  },
  {
    "id": 353,
    "module": "ekipman",
    "title": "oluk tıkanması"
  },
  {
    "id": 354,
    "module": "ekipman",
    "title": "yakıt kapağı"
  },
  {
    "id": 355,
    "module": "ekipman",
    "title": "kabin filtresi"
  },
  {
    "id": 356,
    "module": "ekipman",
    "title": "klima kavrama"
  },
  {
    "id": 357,
    "module": "ekipman",
    "title": "silecek akımı"
  },
  {
    "id": 358,
    "module": "ekipman",
    "title": "korna"
  },
  {
    "id": 359,
    "module": "ekipman",
    "title": "aydınlatma"
  },
  {
    "id": 360,
    "module": "ekipman",
    "title": "ikaz lambası"
  },
  {
    "id": 361,
    "module": "ekipman",
    "title": "kamera"
  },
  {
    "id": 362,
    "module": "ekipman",
    "title": "ultrasonik engel"
  },
  {
    "id": 363,
    "module": "ekipman",
    "title": "eğim açısı"
  },
  {
    "id": 364,
    "module": "ekipman",
    "title": "devrilme koruması"
  },
  {
    "id": 365,
    "module": "ekipman",
    "title": "uzaktan stop"
  },
  {
    "id": 366,
    "module": "ekipman",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 367,
    "module": "ekipman",
    "title": "tutar yuvarlama"
  },
  {
    "id": 368,
    "module": "ekipman",
    "title": "boş girdi reddi"
  },
  {
    "id": 369,
    "module": "ekipman",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 370,
    "module": "ekipman",
    "title": "sonuç özeti"
  },
  {
    "id": 371,
    "module": "ekipman",
    "title": "Türkçe biçim"
  },
  {
    "id": 372,
    "module": "ekipman",
    "title": "saat dilimi damgası"
  },
  {
    "id": 373,
    "module": "ekipman",
    "title": "yetki reddi"
  },
  {
    "id": 374,
    "module": "ekipman",
    "title": "kota kontrolü"
  },
  {
    "id": 375,
    "module": "ekipman",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 376,
    "module": "ekipman",
    "title": "hata mesajı"
  },
  {
    "id": 377,
    "module": "ekipman",
    "title": "ölçü birimi"
  },
  {
    "id": 378,
    "module": "ekipman",
    "title": "eşik uyarısı"
  },
  {
    "id": 379,
    "module": "ekipman",
    "title": "denetim satırı"
  },
  {
    "id": 380,
    "module": "ekipman",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 381,
    "module": "ekipman",
    "title": "toplam"
  },
  {
    "id": 382,
    "module": "ekipman",
    "title": "ortalama"
  },
  {
    "id": 383,
    "module": "ekipman",
    "title": "sapma"
  },
  {
    "id": 384,
    "module": "ekipman",
    "title": "medyan"
  },
  {
    "id": 385,
    "module": "ekipman",
    "title": "üst sınır"
  },
  {
    "id": 386,
    "module": "ekipman",
    "title": "alt sınır"
  },
  {
    "id": 387,
    "module": "ekipman",
    "title": "hedef farkı"
  },
  {
    "id": 388,
    "module": "ekipman",
    "title": "trend"
  },
  {
    "id": 389,
    "module": "ekipman",
    "title": "eşik aşımı"
  },
  {
    "id": 390,
    "module": "ekipman",
    "title": "kuyruk süresi"
  },
  {
    "id": 391,
    "module": "ekipman",
    "title": "öncelik puanı"
  },
  {
    "id": 392,
    "module": "ekipman",
    "title": "birim maliyet"
  },
  {
    "id": 393,
    "module": "ekipman",
    "title": "adet kontrolü"
  },
  {
    "id": 394,
    "module": "ekipman",
    "title": "saatlik hız"
  },
  {
    "id": 395,
    "module": "ekipman",
    "title": "günlük tempo"
  },
  {
    "id": 396,
    "module": "ekipman",
    "title": "haftalık tempo"
  },
  {
    "id": 397,
    "module": "ekipman",
    "title": "aylık tempo"
  },
  {
    "id": 398,
    "module": "ekipman",
    "title": "risk puanı"
  },
  {
    "id": 399,
    "module": "ekipman",
    "title": "güven aralığı"
  },
  {
    "id": 400,
    "module": "ekipman",
    "title": "uç değer"
  },
  {
    "id": 401,
    "module": "offline",
    "title": "Çevrimdışı kayıt kuyruğu"
  },
  {
    "id": 402,
    "module": "offline",
    "title": "PWA kurulum durumu"
  },
  {
    "id": 403,
    "module": "offline",
    "title": "Artan beklemeli yeniden deneme"
  },
  {
    "id": 404,
    "module": "offline",
    "title": "Anında arayüz, sonra sunucu"
  },
  {
    "id": 405,
    "module": "offline",
    "title": "Önbellek sürümü"
  },
  {
    "id": 406,
    "module": "offline",
    "title": "Yerel kayıt koruması"
  },
  {
    "id": 407,
    "module": "offline",
    "title": "Zayıf ağda sade yükleme"
  },
  {
    "id": 408,
    "module": "offline",
    "title": "Sekmeler arası eşitleme"
  },
  {
    "id": 409,
    "module": "offline",
    "title": "Hata sınırı kaydı"
  },
  {
    "id": 410,
    "module": "offline",
    "title": "Depolama kotası"
  },
  {
    "id": 411,
    "module": "offline",
    "title": "servis çalışanı güncellemesi"
  },
  {
    "id": 412,
    "module": "offline",
    "title": "çevrimdışı sayfa"
  },
  {
    "id": 413,
    "module": "offline",
    "title": "arka plan indirme"
  },
  {
    "id": 414,
    "module": "offline",
    "title": "periyodik eşitleme"
  },
  {
    "id": 415,
    "module": "offline",
    "title": "paylaşım hedefi"
  },
  {
    "id": 416,
    "module": "offline",
    "title": "kısayol"
  },
  {
    "id": 417,
    "module": "offline",
    "title": "rozet"
  },
  {
    "id": 418,
    "module": "offline",
    "title": "ekran uyanık"
  },
  {
    "id": 419,
    "module": "offline",
    "title": "tam ekran"
  },
  {
    "id": 420,
    "module": "offline",
    "title": "titreşim"
  },
  {
    "id": 421,
    "module": "offline",
    "title": "düşük pil"
  },
  {
    "id": 422,
    "module": "offline",
    "title": "veri tasarrufu"
  },
  {
    "id": 423,
    "module": "offline",
    "title": "ortam denetimi"
  },
  {
    "id": 424,
    "module": "offline",
    "title": "yazıcı"
  },
  {
    "id": 425,
    "module": "offline",
    "title": "usb tanı"
  },
  {
    "id": 426,
    "module": "offline",
    "title": "seri port"
  },
  {
    "id": 427,
    "module": "offline",
    "title": "nfc etiket"
  },
  {
    "id": 428,
    "module": "offline",
    "title": "rehber aktarımı"
  },
  {
    "id": 429,
    "module": "offline",
    "title": "biyometrik giriş"
  },
  {
    "id": 430,
    "module": "offline",
    "title": "ödeme sayfası"
  },
  {
    "id": 431,
    "module": "offline",
    "title": "imza"
  },
  {
    "id": 432,
    "module": "offline",
    "title": "şema sürümü"
  },
  {
    "id": 433,
    "module": "offline",
    "title": "yedek json"
  },
  {
    "id": 434,
    "module": "offline",
    "title": "geri yükleme"
  },
  {
    "id": 435,
    "module": "offline",
    "title": "seçici eşitleme"
  },
  {
    "id": 436,
    "module": "offline",
    "title": "bant ölçümü"
  },
  {
    "id": 437,
    "module": "offline",
    "title": "çevrimdışı arama"
  },
  {
    "id": 438,
    "module": "offline",
    "title": "bulanık arama"
  },
  {
    "id": 439,
    "module": "offline",
    "title": "arka plan indeks"
  },
  {
    "id": 440,
    "module": "offline",
    "title": "bellek"
  },
  {
    "id": 441,
    "module": "offline",
    "title": "sanal liste"
  },
  {
    "id": 442,
    "module": "offline",
    "title": "sonsuz kaydırma"
  },
  {
    "id": 443,
    "module": "offline",
    "title": "yenile çek"
  },
  {
    "id": 444,
    "module": "offline",
    "title": "kaydırma eylemi"
  },
  {
    "id": 445,
    "module": "offline",
    "title": "uzun basış"
  },
  {
    "id": 446,
    "module": "offline",
    "title": "pano"
  },
  {
    "id": 447,
    "module": "offline",
    "title": "yakınlaştırma"
  },
  {
    "id": 448,
    "module": "offline",
    "title": "klavye kısayolu"
  },
  {
    "id": 449,
    "module": "offline",
    "title": "erişilebilir etiket"
  },
  {
    "id": 450,
    "module": "offline",
    "title": "yüksek karşıtlık"
  },
  {
    "id": 451,
    "module": "offline",
    "title": "yazı boyutu"
  },
  {
    "id": 452,
    "module": "offline",
    "title": "azaltılmış hareket"
  },
  {
    "id": 453,
    "module": "offline",
    "title": "odak kilidi"
  },
  {
    "id": 454,
    "module": "offline",
    "title": "iş parçacığı"
  },
  {
    "id": 455,
    "module": "offline",
    "title": "yayın kanalı"
  },
  {
    "id": 456,
    "module": "offline",
    "title": "websocket yeniden bağlanma"
  },
  {
    "id": 457,
    "module": "offline",
    "title": "istek tekrarı"
  },
  {
    "id": 458,
    "module": "offline",
    "title": "önbellek süresi"
  },
  {
    "id": 459,
    "module": "offline",
    "title": "hız sınırı"
  },
  {
    "id": 460,
    "module": "offline",
    "title": "yük sıkıştırma"
  },
  {
    "id": 461,
    "module": "offline",
    "title": "görsel sıkıştırma"
  },
  {
    "id": 462,
    "module": "offline",
    "title": "kritik css"
  },
  {
    "id": 463,
    "module": "offline",
    "title": "kod bölme"
  },
  {
    "id": 464,
    "module": "offline",
    "title": "ölü kod"
  },
  {
    "id": 465,
    "module": "offline",
    "title": "animasyon karesi"
  },
  {
    "id": 466,
    "module": "offline",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 467,
    "module": "offline",
    "title": "tutar yuvarlama"
  },
  {
    "id": 468,
    "module": "offline",
    "title": "boş girdi reddi"
  },
  {
    "id": 469,
    "module": "offline",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 470,
    "module": "offline",
    "title": "sonuç özeti"
  },
  {
    "id": 471,
    "module": "offline",
    "title": "Türkçe biçim"
  },
  {
    "id": 472,
    "module": "offline",
    "title": "saat dilimi damgası"
  },
  {
    "id": 473,
    "module": "offline",
    "title": "yetki reddi"
  },
  {
    "id": 474,
    "module": "offline",
    "title": "kota kontrolü"
  },
  {
    "id": 475,
    "module": "offline",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 476,
    "module": "offline",
    "title": "hata mesajı"
  },
  {
    "id": 477,
    "module": "offline",
    "title": "ölçü birimi"
  },
  {
    "id": 478,
    "module": "offline",
    "title": "eşik uyarısı"
  },
  {
    "id": 479,
    "module": "offline",
    "title": "denetim satırı"
  },
  {
    "id": 480,
    "module": "offline",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 481,
    "module": "offline",
    "title": "toplam"
  },
  {
    "id": 482,
    "module": "offline",
    "title": "ortalama"
  },
  {
    "id": 483,
    "module": "offline",
    "title": "sapma"
  },
  {
    "id": 484,
    "module": "offline",
    "title": "medyan"
  },
  {
    "id": 485,
    "module": "offline",
    "title": "üst sınır"
  },
  {
    "id": 486,
    "module": "offline",
    "title": "alt sınır"
  },
  {
    "id": 487,
    "module": "offline",
    "title": "hedef farkı"
  },
  {
    "id": 488,
    "module": "offline",
    "title": "trend"
  },
  {
    "id": 489,
    "module": "offline",
    "title": "eşik aşımı"
  },
  {
    "id": 490,
    "module": "offline",
    "title": "kuyruk süresi"
  },
  {
    "id": 491,
    "module": "offline",
    "title": "öncelik puanı"
  },
  {
    "id": 492,
    "module": "offline",
    "title": "birim maliyet"
  },
  {
    "id": 493,
    "module": "offline",
    "title": "adet kontrolü"
  },
  {
    "id": 494,
    "module": "offline",
    "title": "saatlik hız"
  },
  {
    "id": 495,
    "module": "offline",
    "title": "günlük tempo"
  },
  {
    "id": 496,
    "module": "offline",
    "title": "haftalık tempo"
  },
  {
    "id": 497,
    "module": "offline",
    "title": "aylık tempo"
  },
  {
    "id": 498,
    "module": "offline",
    "title": "risk puanı"
  },
  {
    "id": 499,
    "module": "offline",
    "title": "güven aralığı"
  },
  {
    "id": 500,
    "module": "offline",
    "title": "uç değer"
  },
  {
    "id": 501,
    "module": "guvenlik",
    "title": "Passkey ile giriş hazırlığı"
  },
  {
    "id": 502,
    "module": "guvenlik",
    "title": "PIN cihaz kilidi"
  },
  {
    "id": 503,
    "module": "guvenlik",
    "title": "Rol yetki matrisi"
  },
  {
    "id": 504,
    "module": "guvenlik",
    "title": "Yerel kasa notu"
  },
  {
    "id": 505,
    "module": "guvenlik",
    "title": "Bu cihazın yerel kaydını temizle"
  },
  {
    "id": 506,
    "module": "guvenlik",
    "title": "İşlem denetim izi"
  },
  {
    "id": 507,
    "module": "guvenlik",
    "title": "İzinli adres uyarısı"
  },
  {
    "id": 508,
    "module": "guvenlik",
    "title": "Bilinen cihaz kaydı"
  },
  {
    "id": 509,
    "module": "guvenlik",
    "title": "İkinci adım hatırlatması"
  },
  {
    "id": 510,
    "module": "guvenlik",
    "title": "Ekip katılım kodu"
  },
  {
    "id": 511,
    "module": "guvenlik",
    "title": "oturum yenileme"
  },
  {
    "id": 512,
    "module": "guvenlik",
    "title": "çerez politikası"
  },
  {
    "id": 513,
    "module": "guvenlik",
    "title": "csrf başlığı"
  },
  {
    "id": 514,
    "module": "guvenlik",
    "title": "metin temizleme"
  },
  {
    "id": 515,
    "module": "guvenlik",
    "title": "parametreli sorgu"
  },
  {
    "id": 516,
    "module": "guvenlik",
    "title": "içerik güvenlik politikası"
  },
  {
    "id": 517,
    "module": "guvenlik",
    "title": "taşıma güvenliği"
  },
  {
    "id": 518,
    "module": "guvenlik",
    "title": "köken kısıtı"
  },
  {
    "id": 519,
    "module": "guvenlik",
    "title": "istek sınırı"
  },
  {
    "id": 520,
    "module": "guvenlik",
    "title": "giriş kilidi"
  },
  {
    "id": 521,
    "module": "guvenlik",
    "title": "parola karmaşıklığı"
  },
  {
    "id": 522,
    "module": "guvenlik",
    "title": "parola süresi"
  },
  {
    "id": 523,
    "module": "guvenlik",
    "title": "eski parola yasağı"
  },
  {
    "id": 524,
    "module": "guvenlik",
    "title": "kilit bildirimi"
  },
  {
    "id": 525,
    "module": "guvenlik",
    "title": "yönetici jetonu"
  },
  {
    "id": 526,
    "module": "guvenlik",
    "title": "dosya özeti"
  },
  {
    "id": 527,
    "module": "guvenlik",
    "title": "güvenli bağlantı"
  },
  {
    "id": 528,
    "module": "guvenlik",
    "title": "imzalı çerez"
  },
  {
    "id": 529,
    "module": "guvenlik",
    "title": "sosyal giriş"
  },
  {
    "id": 530,
    "module": "guvenlik",
    "title": "kurumsal sso"
  },
  {
    "id": 531,
    "module": "guvenlik",
    "title": "dizin eşitleme"
  },
  {
    "id": 532,
    "module": "guvenlik",
    "title": "anahtar dönüşümü"
  },
  {
    "id": 533,
    "module": "guvenlik",
    "title": "gizli kasa"
  },
  {
    "id": 534,
    "module": "guvenlik",
    "title": "sıfır güven"
  },
  {
    "id": 535,
    "module": "guvenlik",
    "title": "kişisel veri maskesi"
  },
  {
    "id": 536,
    "module": "guvenlik",
    "title": "unutulma hakkı"
  },
  {
    "id": 537,
    "module": "guvenlik",
    "title": "saklama süresi"
  },
  {
    "id": 538,
    "module": "guvenlik",
    "title": "açık rıza"
  },
  {
    "id": 539,
    "module": "guvenlik",
    "title": "olay kaydı"
  },
  {
    "id": 540,
    "module": "guvenlik",
    "title": "zafiyet listesi"
  },
  {
    "id": 541,
    "module": "guvenlik",
    "title": "sızma kontrol listesi"
  },
  {
    "id": 542,
    "module": "guvenlik",
    "title": "bağımlılık denetimi"
  },
  {
    "id": 543,
    "module": "guvenlik",
    "title": "malzeme listesi"
  },
  {
    "id": 544,
    "module": "guvenlik",
    "title": "sertifika süresi"
  },
  {
    "id": 545,
    "module": "guvenlik",
    "title": "dnssec"
  },
  {
    "id": 546,
    "module": "guvenlik",
    "title": "e-posta kimliği"
  },
  {
    "id": 547,
    "module": "guvenlik",
    "title": "yedek doğrulama"
  },
  {
    "id": 548,
    "module": "guvenlik",
    "title": "değişmez defter"
  },
  {
    "id": 549,
    "module": "guvenlik",
    "title": "iş sürekliliği"
  },
  {
    "id": 550,
    "module": "guvenlik",
    "title": "iso kontrol"
  },
  {
    "id": 551,
    "module": "guvenlik",
    "title": "denetim paketi"
  },
  {
    "id": 552,
    "module": "guvenlik",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 553,
    "module": "guvenlik",
    "title": "tutar yuvarlama"
  },
  {
    "id": 554,
    "module": "guvenlik",
    "title": "boş girdi reddi"
  },
  {
    "id": 555,
    "module": "guvenlik",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 556,
    "module": "guvenlik",
    "title": "sonuç özeti"
  },
  {
    "id": 557,
    "module": "guvenlik",
    "title": "Türkçe biçim"
  },
  {
    "id": 558,
    "module": "guvenlik",
    "title": "saat dilimi damgası"
  },
  {
    "id": 559,
    "module": "guvenlik",
    "title": "yetki reddi"
  },
  {
    "id": 560,
    "module": "guvenlik",
    "title": "kota kontrolü"
  },
  {
    "id": 561,
    "module": "guvenlik",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 562,
    "module": "guvenlik",
    "title": "hata mesajı"
  },
  {
    "id": 563,
    "module": "guvenlik",
    "title": "ölçü birimi"
  },
  {
    "id": 564,
    "module": "guvenlik",
    "title": "eşik uyarısı"
  },
  {
    "id": 565,
    "module": "guvenlik",
    "title": "denetim satırı"
  },
  {
    "id": 566,
    "module": "guvenlik",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 567,
    "module": "guvenlik",
    "title": "toplam"
  },
  {
    "id": 568,
    "module": "guvenlik",
    "title": "ortalama"
  },
  {
    "id": 569,
    "module": "guvenlik",
    "title": "sapma"
  },
  {
    "id": 570,
    "module": "guvenlik",
    "title": "medyan"
  },
  {
    "id": 571,
    "module": "guvenlik",
    "title": "üst sınır"
  },
  {
    "id": 572,
    "module": "guvenlik",
    "title": "alt sınır"
  },
  {
    "id": 573,
    "module": "guvenlik",
    "title": "hedef farkı"
  },
  {
    "id": 574,
    "module": "guvenlik",
    "title": "trend"
  },
  {
    "id": 575,
    "module": "guvenlik",
    "title": "eşik aşımı"
  },
  {
    "id": 576,
    "module": "guvenlik",
    "title": "kuyruk süresi"
  },
  {
    "id": 577,
    "module": "guvenlik",
    "title": "öncelik puanı"
  },
  {
    "id": 578,
    "module": "guvenlik",
    "title": "birim maliyet"
  },
  {
    "id": 579,
    "module": "guvenlik",
    "title": "adet kontrolü"
  },
  {
    "id": 580,
    "module": "guvenlik",
    "title": "saatlik hız"
  },
  {
    "id": 581,
    "module": "guvenlik",
    "title": "günlük tempo"
  },
  {
    "id": 582,
    "module": "guvenlik",
    "title": "haftalık tempo"
  },
  {
    "id": 583,
    "module": "guvenlik",
    "title": "aylık tempo"
  },
  {
    "id": 584,
    "module": "guvenlik",
    "title": "risk puanı"
  },
  {
    "id": 585,
    "module": "guvenlik",
    "title": "güven aralığı"
  },
  {
    "id": 586,
    "module": "guvenlik",
    "title": "uç değer"
  },
  {
    "id": 587,
    "module": "guvenlik",
    "title": "eksik alan"
  },
  {
    "id": 588,
    "module": "guvenlik",
    "title": "çift kayıt"
  },
  {
    "id": 589,
    "module": "guvenlik",
    "title": "sıra no"
  },
  {
    "id": 590,
    "module": "guvenlik",
    "title": "vardiya payı"
  },
  {
    "id": 591,
    "module": "guvenlik",
    "title": "bölge payı"
  },
  {
    "id": 592,
    "module": "guvenlik",
    "title": "müşteri payı"
  },
  {
    "id": 593,
    "module": "guvenlik",
    "title": "makine payı"
  },
  {
    "id": 594,
    "module": "guvenlik",
    "title": "nakit payı"
  },
  {
    "id": 595,
    "module": "guvenlik",
    "title": "veresiye payı"
  },
  {
    "id": 596,
    "module": "guvenlik",
    "title": "gecikme payı"
  },
  {
    "id": 597,
    "module": "guvenlik",
    "title": "tamamlanma oranı"
  },
  {
    "id": 598,
    "module": "guvenlik",
    "title": "ek ölçü 1"
  },
  {
    "id": 599,
    "module": "guvenlik",
    "title": "ek ölçü 2"
  },
  {
    "id": 600,
    "module": "guvenlik",
    "title": "ek ölçü 3"
  },
  {
    "id": 601,
    "module": "stok",
    "title": "Depo ve araç stok özeti"
  },
  {
    "id": 602,
    "module": "stok",
    "title": "Yeniden sipariş noktası"
  },
  {
    "id": 603,
    "module": "stok",
    "title": "Barkod sayımı"
  },
  {
    "id": 604,
    "module": "stok",
    "title": "FIFO maliyet"
  },
  {
    "id": 605,
    "module": "stok",
    "title": "Tedarikçi kartı"
  },
  {
    "id": 606,
    "module": "stok",
    "title": "Mal kabul farkı"
  },
  {
    "id": 607,
    "module": "stok",
    "title": "Son kullanma uyarısı"
  },
  {
    "id": 608,
    "module": "stok",
    "title": "Araçlar arası teslim"
  },
  {
    "id": 609,
    "module": "stok",
    "title": "Fire kaydı"
  },
  {
    "id": 610,
    "module": "stok",
    "title": "Stok değeri"
  },
  {
    "id": 611,
    "module": "stok",
    "title": "sayım turu"
  },
  {
    "id": 612,
    "module": "stok",
    "title": "abc sınıfı"
  },
  {
    "id": 613,
    "module": "stok",
    "title": "ekonomik sipariş"
  },
  {
    "id": 614,
    "module": "stok",
    "title": "emniyet stoku"
  },
  {
    "id": 615,
    "module": "stok",
    "title": "tedarik süresi"
  },
  {
    "id": 616,
    "module": "stok",
    "title": "zamanında teslim"
  },
  {
    "id": 617,
    "module": "stok",
    "title": "fiyat farkı"
  },
  {
    "id": 618,
    "module": "stok",
    "title": "iade yetkisi"
  },
  {
    "id": 619,
    "module": "stok",
    "title": "konsinye"
  },
  {
    "id": 620,
    "module": "stok",
    "title": "çapraz sevkiyat"
  },
  {
    "id": 621,
    "module": "stok",
    "title": "raf yerleşimi"
  },
  {
    "id": 622,
    "module": "stok",
    "title": "toplama rotası"
  },
  {
    "id": 623,
    "module": "stok",
    "title": "paket fişi"
  },
  {
    "id": 624,
    "module": "stok",
    "title": "palet adresi"
  },
  {
    "id": 625,
    "module": "stok",
    "title": "seri no"
  },
  {
    "id": 626,
    "module": "stok",
    "title": "lot"
  },
  {
    "id": 627,
    "module": "stok",
    "title": "güvenlik formu"
  },
  {
    "id": 628,
    "module": "stok",
    "title": "sıcaklık"
  },
  {
    "id": 629,
    "module": "stok",
    "title": "nem"
  },
  {
    "id": 630,
    "module": "stok",
    "title": "kafes girişi"
  },
  {
    "id": 631,
    "module": "stok",
    "title": "forklift bakım"
  },
  {
    "id": 632,
    "module": "stok",
    "title": "raf kapasitesi"
  },
  {
    "id": 633,
    "module": "stok",
    "title": "vinç defteri"
  },
  {
    "id": 634,
    "module": "stok",
    "title": "rampa takvimi"
  },
  {
    "id": 635,
    "module": "stok",
    "title": "taşıyıcı puanı"
  },
  {
    "id": 636,
    "module": "stok",
    "title": "konşimento"
  },
  {
    "id": 637,
    "module": "stok",
    "title": "gümrük arşivi"
  },
  {
    "id": 638,
    "module": "stok",
    "title": "konteyner"
  },
  {
    "id": 639,
    "module": "stok",
    "title": "demuraj"
  },
  {
    "id": 640,
    "module": "stok",
    "title": "ambalaj firesi"
  },
  {
    "id": 641,
    "module": "stok",
    "title": "tehlikeli atık"
  },
  {
    "id": 642,
    "module": "stok",
    "title": "hurda geliri"
  },
  {
    "id": 643,
    "module": "stok",
    "title": "bileme planı"
  },
  {
    "id": 644,
    "module": "stok",
    "title": "kaynak teli"
  },
  {
    "id": 645,
    "module": "stok",
    "title": "baret stok"
  },
  {
    "id": 646,
    "module": "stok",
    "title": "ilk yardım"
  },
  {
    "id": 647,
    "module": "stok",
    "title": "yangın tüpü"
  },
  {
    "id": 648,
    "module": "stok",
    "title": "göz duşu"
  },
  {
    "id": 649,
    "module": "stok",
    "title": "jeneratör yakıtı"
  },
  {
    "id": 650,
    "module": "stok",
    "title": "döküntü kiti"
  },
  {
    "id": 651,
    "module": "stok",
    "title": "gürültü dozu"
  },
  {
    "id": 652,
    "module": "stok",
    "title": "maske testi"
  },
  {
    "id": 653,
    "module": "stok",
    "title": "kaza defteri"
  },
  {
    "id": 654,
    "module": "stok",
    "title": "iş güvenliği toplantısı"
  },
  {
    "id": 655,
    "module": "stok",
    "title": "risk kaydı"
  },
  {
    "id": 656,
    "module": "stok",
    "title": "iş izni"
  },
  {
    "id": 657,
    "module": "stok",
    "title": "enerji kesme"
  },
  {
    "id": 658,
    "module": "stok",
    "title": "kapalı alan"
  },
  {
    "id": 659,
    "module": "stok",
    "title": "sıcak iş"
  },
  {
    "id": 660,
    "module": "stok",
    "title": "yükseklik"
  },
  {
    "id": 661,
    "module": "stok",
    "title": "elektrik izni"
  },
  {
    "id": 662,
    "module": "stok",
    "title": "kaldırma planı"
  },
  {
    "id": 663,
    "module": "stok",
    "title": "kazı kontrolü"
  },
  {
    "id": 664,
    "module": "stok",
    "title": "makine kontrolü"
  },
  {
    "id": 665,
    "module": "stok",
    "title": "yorgunluk vardiyası"
  },
  {
    "id": 666,
    "module": "stok",
    "title": "yalnız çalışan"
  },
  {
    "id": 667,
    "module": "stok",
    "title": "panik çağrısı"
  },
  {
    "id": 668,
    "module": "stok",
    "title": "ziyaretçi kaydı"
  },
  {
    "id": 669,
    "module": "stok",
    "title": "taşeron uygunluk"
  },
  {
    "id": 670,
    "module": "stok",
    "title": "devriye noktası"
  },
  {
    "id": 671,
    "module": "stok",
    "title": "kantar fişi"
  },
  {
    "id": 672,
    "module": "stok",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 673,
    "module": "stok",
    "title": "tutar yuvarlama"
  },
  {
    "id": 674,
    "module": "stok",
    "title": "boş girdi reddi"
  },
  {
    "id": 675,
    "module": "stok",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 676,
    "module": "stok",
    "title": "sonuç özeti"
  },
  {
    "id": 677,
    "module": "stok",
    "title": "Türkçe biçim"
  },
  {
    "id": 678,
    "module": "stok",
    "title": "saat dilimi damgası"
  },
  {
    "id": 679,
    "module": "stok",
    "title": "yetki reddi"
  },
  {
    "id": 680,
    "module": "stok",
    "title": "kota kontrolü"
  },
  {
    "id": 681,
    "module": "stok",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 682,
    "module": "stok",
    "title": "hata mesajı"
  },
  {
    "id": 683,
    "module": "stok",
    "title": "ölçü birimi"
  },
  {
    "id": 684,
    "module": "stok",
    "title": "eşik uyarısı"
  },
  {
    "id": 685,
    "module": "stok",
    "title": "denetim satırı"
  },
  {
    "id": 686,
    "module": "stok",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 687,
    "module": "stok",
    "title": "toplam"
  },
  {
    "id": 688,
    "module": "stok",
    "title": "ortalama"
  },
  {
    "id": 689,
    "module": "stok",
    "title": "sapma"
  },
  {
    "id": 690,
    "module": "stok",
    "title": "medyan"
  },
  {
    "id": 691,
    "module": "stok",
    "title": "üst sınır"
  },
  {
    "id": 692,
    "module": "stok",
    "title": "alt sınır"
  },
  {
    "id": 693,
    "module": "stok",
    "title": "hedef farkı"
  },
  {
    "id": 694,
    "module": "stok",
    "title": "trend"
  },
  {
    "id": 695,
    "module": "stok",
    "title": "eşik aşımı"
  },
  {
    "id": 696,
    "module": "stok",
    "title": "kuyruk süresi"
  },
  {
    "id": 697,
    "module": "stok",
    "title": "öncelik puanı"
  },
  {
    "id": 698,
    "module": "stok",
    "title": "birim maliyet"
  },
  {
    "id": 699,
    "module": "stok",
    "title": "adet kontrolü"
  },
  {
    "id": 700,
    "module": "stok",
    "title": "saatlik hız"
  },
  {
    "id": 701,
    "module": "crm",
    "title": "Müşteri 360 özeti"
  },
  {
    "id": 702,
    "module": "crm",
    "title": "Hizmet talebi kartı"
  },
  {
    "id": 703,
    "module": "crm",
    "title": "Randevu mesaj taslağı"
  },
  {
    "id": 704,
    "module": "crm",
    "title": "Memnuniyet notu"
  },
  {
    "id": 705,
    "module": "crm",
    "title": "Sözleşme yenileme"
  },
  {
    "id": 706,
    "module": "crm",
    "title": "Müşteri etiketi"
  },
  {
    "id": 707,
    "module": "crm",
    "title": "Teklif hunisi"
  },
  {
    "id": 708,
    "module": "crm",
    "title": "İş teslim notu"
  },
  {
    "id": 709,
    "module": "crm",
    "title": "İletişim zaman çizelgesi"
  },
  {
    "id": 710,
    "module": "crm",
    "title": "Kredi skoru"
  },
  {
    "id": 711,
    "module": "crm",
    "title": "Randevu defteri"
  },
  {
    "id": 712,
    "module": "crm",
    "title": "Çakışan randevu kontrolü"
  },
  {
    "id": 713,
    "module": "crm",
    "title": "Randevuda cari bakiye"
  },
  {
    "id": 714,
    "module": "crm",
    "title": "doğum günü notu"
  },
  {
    "id": 715,
    "module": "crm",
    "title": "sadakat puanı"
  },
  {
    "id": 716,
    "module": "crm",
    "title": "yönlendirme primi"
  },
  {
    "id": 717,
    "module": "crm",
    "title": "vip yönlendirme"
  },
  {
    "id": 718,
    "module": "crm",
    "title": "self servis erteleme"
  },
  {
    "id": 719,
    "module": "crm",
    "title": "teklif onayı"
  },
  {
    "id": 720,
    "module": "crm",
    "title": "kapora"
  },
  {
    "id": 721,
    "module": "crm",
    "title": "tekrarlayan fatura"
  },
  {
    "id": 722,
    "module": "crm",
    "title": "duygu eğilimi"
  },
  {
    "id": 723,
    "module": "crm",
    "title": "ayrılma uyarısı"
  },
  {
    "id": 724,
    "module": "crm",
    "title": "ek satış"
  },
  {
    "id": 725,
    "module": "crm",
    "title": "şikayet kaydı"
  },
  {
    "id": 726,
    "module": "crm",
    "title": "sla cezası"
  },
  {
    "id": 727,
    "module": "crm",
    "title": "garanti portalı"
  },
  {
    "id": 728,
    "module": "crm",
    "title": "varlık geçmişi"
  },
  {
    "id": 729,
    "module": "crm",
    "title": "belge klasörü"
  },
  {
    "id": 730,
    "module": "crm",
    "title": "fiyat kademesi"
  },
  {
    "id": 731,
    "module": "crm",
    "title": "vergi istisnası"
  },
  {
    "id": 732,
    "module": "crm",
    "title": "sipariş no"
  },
  {
    "id": 733,
    "module": "crm",
    "title": "saha tarifi"
  },
  {
    "id": 734,
    "module": "crm",
    "title": "tehlike etiketi"
  },
  {
    "id": 735,
    "module": "crm",
    "title": "tercih edilen usta"
  },
  {
    "id": 736,
    "module": "crm",
    "title": "kara liste"
  },
  {
    "id": 737,
    "module": "crm",
    "title": "karşılama listesi"
  },
  {
    "id": 738,
    "module": "crm",
    "title": "sezon duyurusu"
  },
  {
    "id": 739,
    "module": "crm",
    "title": "bülten"
  },
  {
    "id": 740,
    "module": "crm",
    "title": "arama kaydı"
  },
  {
    "id": 741,
    "module": "crm",
    "title": "kaçan arama"
  },
  {
    "id": 742,
    "module": "crm",
    "title": "toplantı"
  },
  {
    "id": 743,
    "module": "crm",
    "title": "özet rapor"
  },
  {
    "id": 744,
    "module": "crm",
    "title": "karar verici"
  },
  {
    "id": 745,
    "module": "crm",
    "title": "acil kişi ağacı"
  },
  {
    "id": 746,
    "module": "crm",
    "title": "taşeron puanı"
  },
  {
    "id": 747,
    "module": "crm",
    "title": "staj takibi"
  },
  {
    "id": 748,
    "module": "crm",
    "title": "sertifika yenileme"
  },
  {
    "id": 749,
    "module": "crm",
    "title": "gizlilik sözleşmesi"
  },
  {
    "id": 750,
    "module": "crm",
    "title": "rekabet yasağı"
  },
  {
    "id": 751,
    "module": "crm",
    "title": "uyuşmazlık dosyası"
  },
  {
    "id": 752,
    "module": "crm",
    "title": "tutanak"
  },
  {
    "id": 753,
    "module": "crm",
    "title": "vekalet"
  },
  {
    "id": 754,
    "module": "crm",
    "title": "hisse defteri"
  },
  {
    "id": 755,
    "module": "crm",
    "title": "opsiyon"
  },
  {
    "id": 756,
    "module": "crm",
    "title": "kredi sözleşmesi"
  },
  {
    "id": 757,
    "module": "crm",
    "title": "teminat mektubu"
  },
  {
    "id": 758,
    "module": "crm",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 759,
    "module": "crm",
    "title": "tutar yuvarlama"
  },
  {
    "id": 760,
    "module": "crm",
    "title": "boş girdi reddi"
  },
  {
    "id": 761,
    "module": "crm",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 762,
    "module": "crm",
    "title": "sonuç özeti"
  },
  {
    "id": 763,
    "module": "crm",
    "title": "Türkçe biçim"
  },
  {
    "id": 764,
    "module": "crm",
    "title": "saat dilimi damgası"
  },
  {
    "id": 765,
    "module": "crm",
    "title": "yetki reddi"
  },
  {
    "id": 766,
    "module": "crm",
    "title": "kota kontrolü"
  },
  {
    "id": 767,
    "module": "crm",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 768,
    "module": "crm",
    "title": "hata mesajı"
  },
  {
    "id": 769,
    "module": "crm",
    "title": "ölçü birimi"
  },
  {
    "id": 770,
    "module": "crm",
    "title": "eşik uyarısı"
  },
  {
    "id": 771,
    "module": "crm",
    "title": "denetim satırı"
  },
  {
    "id": 772,
    "module": "crm",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 773,
    "module": "crm",
    "title": "toplam"
  },
  {
    "id": 774,
    "module": "crm",
    "title": "ortalama"
  },
  {
    "id": 775,
    "module": "crm",
    "title": "sapma"
  },
  {
    "id": 776,
    "module": "crm",
    "title": "medyan"
  },
  {
    "id": 777,
    "module": "crm",
    "title": "üst sınır"
  },
  {
    "id": 778,
    "module": "crm",
    "title": "alt sınır"
  },
  {
    "id": 779,
    "module": "crm",
    "title": "hedef farkı"
  },
  {
    "id": 780,
    "module": "crm",
    "title": "trend"
  },
  {
    "id": 781,
    "module": "crm",
    "title": "eşik aşımı"
  },
  {
    "id": 782,
    "module": "crm",
    "title": "kuyruk süresi"
  },
  {
    "id": 783,
    "module": "crm",
    "title": "öncelik puanı"
  },
  {
    "id": 784,
    "module": "crm",
    "title": "birim maliyet"
  },
  {
    "id": 785,
    "module": "crm",
    "title": "adet kontrolü"
  },
  {
    "id": 786,
    "module": "crm",
    "title": "saatlik hız"
  },
  {
    "id": 787,
    "module": "crm",
    "title": "günlük tempo"
  },
  {
    "id": 788,
    "module": "crm",
    "title": "haftalık tempo"
  },
  {
    "id": 789,
    "module": "crm",
    "title": "aylık tempo"
  },
  {
    "id": 790,
    "module": "crm",
    "title": "risk puanı"
  },
  {
    "id": 791,
    "module": "crm",
    "title": "güven aralığı"
  },
  {
    "id": 792,
    "module": "crm",
    "title": "uç değer"
  },
  {
    "id": 793,
    "module": "crm",
    "title": "eksik alan"
  },
  {
    "id": 794,
    "module": "crm",
    "title": "çift kayıt"
  },
  {
    "id": 795,
    "module": "crm",
    "title": "sıra no"
  },
  {
    "id": 796,
    "module": "crm",
    "title": "vardiya payı"
  },
  {
    "id": 797,
    "module": "crm",
    "title": "bölge payı"
  },
  {
    "id": 798,
    "module": "crm",
    "title": "müşteri payı"
  },
  {
    "id": 799,
    "module": "crm",
    "title": "makine payı"
  },
  {
    "id": 800,
    "module": "crm",
    "title": "nakit payı"
  },
  {
    "id": 801,
    "module": "rapor",
    "title": "Günlük yönetici özeti"
  },
  {
    "id": 802,
    "module": "rapor",
    "title": "Ölçü seçerek rapor"
  },
  {
    "id": 803,
    "module": "rapor",
    "title": "Gelir tahmini"
  },
  {
    "id": 804,
    "module": "rapor",
    "title": "Usta verim kartı"
  },
  {
    "id": 805,
    "module": "rapor",
    "title": "Bölge gelir özeti"
  },
  {
    "id": 806,
    "module": "rapor",
    "title": "Makine maliyet özeti"
  },
  {
    "id": 807,
    "module": "rapor",
    "title": "Malzeme fire oranı"
  },
  {
    "id": 808,
    "module": "rapor",
    "title": "Vergi dönemi özeti"
  },
  {
    "id": 809,
    "module": "rapor",
    "title": "Zamanlanmış rapor"
  },
  {
    "id": 810,
    "module": "rapor",
    "title": "Nakit sapma uyarısı"
  },
  {
    "id": 811,
    "module": "rapor",
    "title": "kohort"
  },
  {
    "id": 812,
    "module": "rapor",
    "title": "yaşam boyu değer"
  },
  {
    "id": 813,
    "module": "rapor",
    "title": "edinme maliyeti"
  },
  {
    "id": 814,
    "module": "rapor",
    "title": "geri ödeme süresi"
  },
  {
    "id": 815,
    "module": "rapor",
    "title": "brüt marj"
  },
  {
    "id": 816,
    "module": "rapor",
    "title": "katkı payı"
  },
  {
    "id": 817,
    "module": "rapor",
    "title": "faaliyet kaldıracı"
  },
  {
    "id": 818,
    "module": "rapor",
    "title": "dupont"
  },
  {
    "id": 819,
    "module": "rapor",
    "title": "ekonomik katma değer"
  },
  {
    "id": 820,
    "module": "rapor",
    "title": "nakit döngüsü"
  },
  {
    "id": 821,
    "module": "rapor",
    "title": "stok gün"
  },
  {
    "id": 822,
    "module": "rapor",
    "title": "alacak gün"
  },
  {
    "id": 823,
    "module": "rapor",
    "title": "borç gün"
  },
  {
    "id": 824,
    "module": "rapor",
    "title": "cari oran"
  },
  {
    "id": 825,
    "module": "rapor",
    "title": "asit test"
  },
  {
    "id": 826,
    "module": "rapor",
    "title": "faiz karşılama"
  },
  {
    "id": 827,
    "module": "rapor",
    "title": "borç öz kaynak"
  },
  {
    "id": 828,
    "module": "rapor",
    "title": "aktif kârlılık"
  },
  {
    "id": 829,
    "module": "rapor",
    "title": "öz kaynak kârlılık"
  },
  {
    "id": 830,
    "module": "rapor",
    "title": "varlık devir"
  },
  {
    "id": 831,
    "module": "rapor",
    "title": "sürdürülebilir büyüme"
  },
  {
    "id": 832,
    "module": "rapor",
    "title": "regresyon"
  },
  {
    "id": 833,
    "module": "rapor",
    "title": "mevsim endeksi"
  },
  {
    "id": 834,
    "module": "rapor",
    "title": "hareketli ortalama"
  },
  {
    "id": 835,
    "module": "rapor",
    "title": "üstel düzeltme"
  },
  {
    "id": 836,
    "module": "rapor",
    "title": "senaryo"
  },
  {
    "id": 837,
    "module": "rapor",
    "title": "marjinal analiz"
  },
  {
    "id": 838,
    "module": "rapor",
    "title": "abc maliyet"
  },
  {
    "id": 839,
    "module": "rapor",
    "title": "başabaş duyarlılığı"
  },
  {
    "id": 840,
    "module": "rapor",
    "title": "güvenlik payı"
  },
  {
    "id": 841,
    "module": "rapor",
    "title": "tedarik riski"
  },
  {
    "id": 842,
    "module": "rapor",
    "title": "müşteri yoğunlaşması"
  },
  {
    "id": 843,
    "module": "rapor",
    "title": "bölge çeşitliliği"
  },
  {
    "id": 844,
    "module": "rapor",
    "title": "personel devir maliyeti"
  },
  {
    "id": 845,
    "module": "rapor",
    "title": "eğitim getirisi"
  },
  {
    "id": 846,
    "module": "rapor",
    "title": "devamsızlık"
  },
  {
    "id": 847,
    "module": "rapor",
    "title": "fazla mesai"
  },
  {
    "id": 848,
    "module": "rapor",
    "title": "işgücü verimi"
  },
  {
    "id": 849,
    "module": "rapor",
    "title": "kapasite"
  },
  {
    "id": 850,
    "module": "rapor",
    "title": "darboğaz"
  },
  {
    "id": 851,
    "module": "rapor",
    "title": "ekipman etkinliği"
  },
  {
    "id": 852,
    "module": "rapor",
    "title": "arıza arası süre"
  },
  {
    "id": 853,
    "module": "rapor",
    "title": "onarım süresi"
  },
  {
    "id": 854,
    "module": "rapor",
    "title": "kullanılabilirlik"
  },
  {
    "id": 855,
    "module": "rapor",
    "title": "bakım saati maliyeti"
  },
  {
    "id": 856,
    "module": "rapor",
    "title": "önleyici bakım oranı"
  },
  {
    "id": 857,
    "module": "rapor",
    "title": "yedek devir"
  },
  {
    "id": 858,
    "module": "rapor",
    "title": "atıl stok"
  },
  {
    "id": 859,
    "module": "rapor",
    "title": "depo doluluk"
  },
  {
    "id": 860,
    "module": "rapor",
    "title": "rota sapma maliyeti"
  },
  {
    "id": 861,
    "module": "rapor",
    "title": "yakıt oynaklığı"
  },
  {
    "id": 862,
    "module": "rapor",
    "title": "karbon ayak izi"
  },
  {
    "id": 863,
    "module": "rapor",
    "title": "enerji endeksi"
  },
  {
    "id": 864,
    "module": "rapor",
    "title": "su tüketimi"
  },
  {
    "id": 865,
    "module": "rapor",
    "title": "atık ayrıştırma"
  },
  {
    "id": 866,
    "module": "rapor",
    "title": "uyum riski"
  },
  {
    "id": 867,
    "module": "rapor",
    "title": "denetim bulgusu"
  },
  {
    "id": 868,
    "module": "rapor",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 869,
    "module": "rapor",
    "title": "tutar yuvarlama"
  },
  {
    "id": 870,
    "module": "rapor",
    "title": "boş girdi reddi"
  },
  {
    "id": 871,
    "module": "rapor",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 872,
    "module": "rapor",
    "title": "sonuç özeti"
  },
  {
    "id": 873,
    "module": "rapor",
    "title": "Türkçe biçim"
  },
  {
    "id": 874,
    "module": "rapor",
    "title": "saat dilimi damgası"
  },
  {
    "id": 875,
    "module": "rapor",
    "title": "yetki reddi"
  },
  {
    "id": 876,
    "module": "rapor",
    "title": "kota kontrolü"
  },
  {
    "id": 877,
    "module": "rapor",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 878,
    "module": "rapor",
    "title": "hata mesajı"
  },
  {
    "id": 879,
    "module": "rapor",
    "title": "ölçü birimi"
  },
  {
    "id": 880,
    "module": "rapor",
    "title": "eşik uyarısı"
  },
  {
    "id": 881,
    "module": "rapor",
    "title": "denetim satırı"
  },
  {
    "id": 882,
    "module": "rapor",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 883,
    "module": "rapor",
    "title": "toplam"
  },
  {
    "id": 884,
    "module": "rapor",
    "title": "ortalama"
  },
  {
    "id": 885,
    "module": "rapor",
    "title": "sapma"
  },
  {
    "id": 886,
    "module": "rapor",
    "title": "medyan"
  },
  {
    "id": 887,
    "module": "rapor",
    "title": "üst sınır"
  },
  {
    "id": 888,
    "module": "rapor",
    "title": "alt sınır"
  },
  {
    "id": 889,
    "module": "rapor",
    "title": "hedef farkı"
  },
  {
    "id": 890,
    "module": "rapor",
    "title": "trend"
  },
  {
    "id": 891,
    "module": "rapor",
    "title": "eşik aşımı"
  },
  {
    "id": 892,
    "module": "rapor",
    "title": "kuyruk süresi"
  },
  {
    "id": 893,
    "module": "rapor",
    "title": "öncelik puanı"
  },
  {
    "id": 894,
    "module": "rapor",
    "title": "birim maliyet"
  },
  {
    "id": 895,
    "module": "rapor",
    "title": "adet kontrolü"
  },
  {
    "id": 896,
    "module": "rapor",
    "title": "saatlik hız"
  },
  {
    "id": 897,
    "module": "rapor",
    "title": "günlük tempo"
  },
  {
    "id": 898,
    "module": "rapor",
    "title": "haftalık tempo"
  },
  {
    "id": 899,
    "module": "rapor",
    "title": "aylık tempo"
  },
  {
    "id": 900,
    "module": "rapor",
    "title": "risk puanı"
  },
  {
    "id": 901,
    "module": "platform",
    "title": "Dış sorgu sözleşmesi"
  },
  {
    "id": 902,
    "module": "platform",
    "title": "Olay bildirimi imzası"
  },
  {
    "id": 903,
    "module": "platform",
    "title": "Takvim eşitleme hazırlığı"
  },
  {
    "id": 904,
    "module": "platform",
    "title": "Zamanlanmış iş kaydı"
  },
  {
    "id": 905,
    "module": "platform",
    "title": "Özellik bayrağı"
  },
  {
    "id": 906,
    "module": "platform",
    "title": "Muhasebe dışa aktarma satırı"
  },
  {
    "id": 907,
    "module": "platform",
    "title": "Mesaj kanalı yedeği"
  },
  {
    "id": 908,
    "module": "platform",
    "title": "Yedek alma kontrol listesi"
  },
  {
    "id": 909,
    "module": "platform",
    "title": "Ortam anahtarı durumu"
  },
  {
    "id": 910,
    "module": "platform",
    "title": "API deneme kartı"
  },
  {
    "id": 911,
    "module": "platform",
    "title": "anahtar kotası"
  },
  {
    "id": 912,
    "module": "platform",
    "title": "oauth istemcisi"
  },
  {
    "id": 913,
    "module": "platform",
    "title": "webhook yeniden deneme"
  },
  {
    "id": 914,
    "module": "platform",
    "title": "imza doğrulama"
  },
  {
    "id": 915,
    "module": "platform",
    "title": "kullanım ölçümü"
  },
  {
    "id": 916,
    "module": "platform",
    "title": "şema kartı"
  },
  {
    "id": 917,
    "module": "platform",
    "title": "olay akışı"
  },
  {
    "id": 918,
    "module": "platform",
    "title": "önbellek katmanı"
  },
  {
    "id": 919,
    "module": "platform",
    "title": "metin arama"
  },
  {
    "id": 920,
    "module": "platform",
    "title": "imaj sürümü"
  },
  {
    "id": 921,
    "module": "platform",
    "title": "dağıtım listesi"
  },
  {
    "id": 922,
    "module": "platform",
    "title": "altyapı betiği"
  },
  {
    "id": 923,
    "module": "platform",
    "title": "test hattı"
  },
  {
    "id": 924,
    "module": "platform",
    "title": "sürüm notu üretimi"
  },
  {
    "id": 925,
    "module": "platform",
    "title": "uçtan uca test"
  },
  {
    "id": 926,
    "module": "platform",
    "title": "birim test"
  },
  {
    "id": 927,
    "module": "platform",
    "title": "kapsama"
  },
  {
    "id": 928,
    "module": "platform",
    "title": "statik denetim"
  },
  {
    "id": 929,
    "module": "platform",
    "title": "bağımlılık güncelleme"
  },
  {
    "id": 930,
    "module": "platform",
    "title": "göç geri alma"
  },
  {
    "id": 931,
    "module": "platform",
    "title": "kanarya"
  },
  {
    "id": 932,
    "module": "platform",
    "title": "mavi yeşil"
  },
  {
    "id": 933,
    "module": "platform",
    "title": "yük testi"
  },
  {
    "id": 934,
    "module": "platform",
    "title": "gerçek kullanıcı ölçümü"
  },
  {
    "id": 935,
    "module": "platform",
    "title": "hata iletimi"
  },
  {
    "id": 936,
    "module": "platform",
    "title": "iz sürme"
  },
  {
    "id": 937,
    "module": "platform",
    "title": "günlük toplama"
  },
  {
    "id": 938,
    "module": "platform",
    "title": "metrik pano"
  },
  {
    "id": 939,
    "module": "platform",
    "title": "uptime"
  },
  {
    "id": 940,
    "module": "platform",
    "title": "durum sayfası"
  },
  {
    "id": 941,
    "module": "platform",
    "title": "geri bildirim parçacığı"
  },
  {
    "id": 942,
    "module": "platform",
    "title": "pwa manifest"
  },
  {
    "id": 943,
    "module": "platform",
    "title": "paylaşım kartı"
  },
  {
    "id": 944,
    "module": "platform",
    "title": "site haritası"
  },
  {
    "id": 945,
    "module": "platform",
    "title": "robots"
  },
  {
    "id": 946,
    "module": "platform",
    "title": "güvenlik dosyası"
  },
  {
    "id": 947,
    "module": "platform",
    "title": "gizlilik metni"
  },
  {
    "id": 948,
    "module": "platform",
    "title": "dil dosyası"
  },
  {
    "id": 949,
    "module": "platform",
    "title": "saat dilimi"
  },
  {
    "id": 950,
    "module": "platform",
    "title": "birim çevirici"
  },
  {
    "id": 951,
    "module": "platform",
    "title": "tema değişkeni"
  },
  {
    "id": 952,
    "module": "platform",
    "title": "beyaz etiket"
  },
  {
    "id": 953,
    "module": "platform",
    "title": "kiracı ayrımı"
  },
  {
    "id": 954,
    "module": "platform",
    "title": "satır güvenliği"
  },
  {
    "id": 955,
    "module": "platform",
    "title": "yavaş sorgu"
  },
  {
    "id": 956,
    "module": "platform",
    "title": "disk doluluk"
  },
  {
    "id": 957,
    "module": "platform",
    "title": "sertifika yenileme"
  },
  {
    "id": 958,
    "module": "platform",
    "title": "dns kaydı"
  },
  {
    "id": 959,
    "module": "platform",
    "title": "e-posta sağlığı"
  },
  {
    "id": 960,
    "module": "platform",
    "title": "yedek tatbikatı"
  },
  {
    "id": 961,
    "module": "platform",
    "title": "denetim paketi"
  },
  {
    "id": 962,
    "module": "platform",
    "title": "son sıkılaştırma kontrolü"
  },
  {
    "id": 963,
    "module": "platform",
    "title": "kayıt bütünlüğü"
  },
  {
    "id": 964,
    "module": "platform",
    "title": "tutar yuvarlama"
  },
  {
    "id": 965,
    "module": "platform",
    "title": "boş girdi reddi"
  },
  {
    "id": 966,
    "module": "platform",
    "title": "tekrar çalıştırma"
  },
  {
    "id": 967,
    "module": "platform",
    "title": "sonuç özeti"
  },
  {
    "id": 968,
    "module": "platform",
    "title": "Türkçe biçim"
  },
  {
    "id": 969,
    "module": "platform",
    "title": "saat dilimi damgası"
  },
  {
    "id": 970,
    "module": "platform",
    "title": "yetki reddi"
  },
  {
    "id": 971,
    "module": "platform",
    "title": "kota kontrolü"
  },
  {
    "id": 972,
    "module": "platform",
    "title": "çevrimdışı yedek"
  },
  {
    "id": 973,
    "module": "platform",
    "title": "hata mesajı"
  },
  {
    "id": 974,
    "module": "platform",
    "title": "ölçü birimi"
  },
  {
    "id": 975,
    "module": "platform",
    "title": "eşik uyarısı"
  },
  {
    "id": 976,
    "module": "platform",
    "title": "denetim satırı"
  },
  {
    "id": 977,
    "module": "platform",
    "title": "dışa aktarma satırı"
  },
  {
    "id": 978,
    "module": "platform",
    "title": "toplam"
  },
  {
    "id": 979,
    "module": "platform",
    "title": "ortalama"
  },
  {
    "id": 980,
    "module": "platform",
    "title": "sapma"
  },
  {
    "id": 981,
    "module": "platform",
    "title": "medyan"
  },
  {
    "id": 982,
    "module": "platform",
    "title": "üst sınır"
  },
  {
    "id": 983,
    "module": "platform",
    "title": "alt sınır"
  },
  {
    "id": 984,
    "module": "platform",
    "title": "hedef farkı"
  },
  {
    "id": 985,
    "module": "platform",
    "title": "trend"
  },
  {
    "id": 986,
    "module": "platform",
    "title": "eşik aşımı"
  },
  {
    "id": 987,
    "module": "platform",
    "title": "kuyruk süresi"
  },
  {
    "id": 988,
    "module": "platform",
    "title": "öncelik puanı"
  },
  {
    "id": 989,
    "module": "platform",
    "title": "birim maliyet"
  },
  {
    "id": 990,
    "module": "platform",
    "title": "adet kontrolü"
  },
  {
    "id": 991,
    "module": "platform",
    "title": "saatlik hız"
  },
  {
    "id": 992,
    "module": "platform",
    "title": "günlük tempo"
  },
  {
    "id": 993,
    "module": "platform",
    "title": "haftalık tempo"
  },
  {
    "id": 994,
    "module": "platform",
    "title": "aylık tempo"
  },
  {
    "id": 995,
    "module": "platform",
    "title": "risk puanı"
  },
  {
    "id": 996,
    "module": "platform",
    "title": "güven aralığı"
  },
  {
    "id": 997,
    "module": "platform",
    "title": "uç değer"
  },
  {
    "id": 998,
    "module": "platform",
    "title": "eksik alan"
  },
  {
    "id": 999,
    "module": "platform",
    "title": "çift kayıt"
  },
  {
    "id": 1000,
    "module": "platform",
    "title": "sıra no"
  }
];
