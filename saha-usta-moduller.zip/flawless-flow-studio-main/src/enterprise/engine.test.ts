import { describe, expect, it } from "vitest";
import { ENTERPRISE_FEATURES } from "./catalog";
import {
  balancedEntry,
  creditScore,
  distanceMeters,
  fifoCost,
  insideJobGeofence,
  intervalsOverlap,
  maintenanceDue,
  parseFieldNote,
  runEnterpriseFeature,
  vatBreakdown,
} from "./engine";

describe("kurumsal motor", () => {
  it("bin özelliği tekil kimlikle tutar", () => {
    expect(ENTERPRISE_FEATURES).toHaveLength(1000);
    expect(new Set(ENTERPRISE_FEATURES.map((feature) => feature.id)).size).toBe(1000);
  });

  it("saha notundan tahsilat çıkarır", () => {
    const note = parseFieldNote("Ahmet ustadan 2000 TL nakit alındı, yarın kuzey tarlaya boru döşenecek");
    expect(note.amount).toBe(2000);
    expect(note.method).toBe("nakit");
    expect(note.customerHint?.toLocaleLowerCase("tr")).toBe("ahmet");
    expect(note.action).toBe("boru döşeme");
    expect(note.when).toBe("yarın");
  });

  it("yevmiye fişini dengeler ve KDV ayırır", () => {
    const entry = balancedEntry(1500, "Kasa", "Cari");
    expect(entry.debit).toBe(entry.credit);
    expect(vatBreakdown(120, 20)).toEqual({ rate: 20, net: 100, vat: 20, gross: 120 });
  });

  it("50 metre çitini ve bakım saatini hesaplar", () => {
    const fence = insideJobGeofence({ lat: 41, lng: 29, siteLat: 41, siteLng: 29 });
    expect(fence.onSite).toBe(true);
    expect(distanceMeters(41, 29, 41.001, 29)).toBeGreaterThan(50);
    expect(maintenanceDue(30).due).toBe(true);
    expect(maintenanceDue(29.9).due).toBe(false);
  });

  it("stok maliyeti, kredi ve randevu çakışmasını üretir", () => {
    expect(fifoCost([{ qty: 1, unit: 10 }, { qty: 5, unit: 20 }], 2).cost).toBe(30);
    expect(creditScore(1000, 250)).toBe(25);
    expect(intervalsOverlap(9, 11, 10, 12)).toBe(true);
  });

  it("katalogdaki her modül bir sonuç döndürür", () => {
    const sample = ENTERPRISE_FEATURES.filter((feature) => feature.id % 100 === 1);
    for (const feature of sample) {
      const result = runEnterpriseFeature(feature, {
        text: "acil bakım",
        amount: 1000,
        rate: 20,
        lat: 41,
        lng: 29,
        siteLat: 41.01,
        siteLng: 29,
        hours: 32,
        quantity: 3,
        cost: 400,
        attempt: 2,
      });
      expect(result.ok).toBe(true);
      expect(result.id).toBe(feature.id);
    }
  });
});
