export interface FeatureContext {
  text: string;
  amount: number;
  rate: number;
  lat: number;
  lng: number;
  siteLat: number;
  siteLng: number;
  hours: number;
  quantity: number;
  cost: number;
  attempt: number;
}

export const EMPTY_CONTEXT: FeatureContext = {
  text: "",
  amount: 0,
  rate: 20,
  lat: 0,
  lng: 0,
  siteLat: 0,
  siteLng: 0,
  hours: 0,
  quantity: 1,
  cost: 0,
  attempt: 0,
};

export interface ParsedFieldNote {
  amount: number | null;
  method: "nakit" | "borc" | "havale" | null;
  when: string | null;
  action: string | null;
  customerHint: string | null;
  priority: "P0" | "P1" | "P2" | "P3";
  raw: string;
}

export interface EnterpriseFeatureMeta {
  id: number;
  module: EnterpriseModule;
  title: string;
}

export type EnterpriseModule =
  | "ai"
  | "filo"
  | "finans"
  | "ekipman"
  | "offline"
  | "guvenlik"
  | "stok"
  | "crm"
  | "rapor"
  | "platform";

export interface FeatureResult {
  id: number;
  module: EnterpriseModule;
  title: string;
  ok: boolean;
  summary: string;
  data: Record<string, string | number | boolean | null>;
}

const round = (n: number) => Math.round(n * 100) / 100;

export function parseFieldNote(raw: string): ParsedFieldNote {
  const text = raw.trim();
  const money = text.match(/(\d+(?:[.,]\d+)?)\s*(?:tl|lira|₺)/i);
  const amountToken = money?.[1];
  const amount = amountToken ? Number(amountToken.replace(",", ".")) : null;
  const method = /nakit/i.test(text) ? "nakit" : /havale|eft/i.test(text) ? "havale" : /borç|borc|veresiye/i.test(text) ? "borc" : null;
  const when = /yarın|yarin/i.test(text) ? "yarın" : /bugün|bugun/i.test(text) ? "bugün" : null;
  const customer = text.match(/([A-Za-zÇĞİÖŞÜçğıöşü]+)\s+usta/i);
  const action = /boru/i.test(text)
    ? "boru döşeme"
    : /biç|bicim|çim|cim/i.test(text)
      ? "çim biçme"
      : /bakım|bakim/i.test(text)
        ? "bakım"
        : null;
  return {
    amount: amount !== null && Number.isFinite(amount) ? amount : null,
    method,
    when,
    action,
    customerHint: customer?.[1] ?? null,
    priority: priorityFromText(text),
    raw: text,
  };
}

export function priorityFromText(text: string): ParsedFieldNote["priority"] {
  if (/yangın|yangin|kaza|acil|p0/i.test(text)) return "P0";
  if (/arıza|ariza|bozuk|kaçak|kacak/i.test(text)) return "P1";
  if (/bakım|bakim|kontrol/i.test(text)) return "P2";
  return "P3";
}

export function estimateTokens(text: string) {
  return Math.max(1, Math.ceil(text.trim().length / 4));
}

const POSITIVE = ["teşekkür", "tesekkur", "iyi", "memnun", "tamam", "güzel", "guzel"];
const NEGATIVE = ["şikayet", "sikayet", "kötü", "kotu", "gecik", "bozuk", "kızgın", "kizgin"];

export function sentimentScore(text: string) {
  const value = text.toLocaleLowerCase("tr");
  const plus = POSITIVE.filter((word) => value.includes(word)).length;
  const minus = NEGATIVE.filter((word) => value.includes(word)).length;
  return plus - minus;
}

const FIELD_GLOSSARY: Record<string, string> = {
  tarla: "field",
  boru: "pipe",
  bakım: "maintenance",
  yevmiye: "day wage",
  makbuz: "receipt",
  müşteri: "customer",
  musteri: "customer",
};

export function translateFieldTerms(text: string) {
  let output = text;
  for (const [tr, en] of Object.entries(FIELD_GLOSSARY)) {
    output = output.replace(new RegExp(tr, "gi"), en);
  }
  return output;
}

export function estimateJobHours(text: string, amount: number) {
  let hours = 2;
  if (/boru/i.test(text)) hours += 3;
  if (/tarla/i.test(text)) hours += 2;
  if (/yağmur|yagmur|çamur|camur/i.test(text)) hours += 0.5;
  hours += Math.min(6, amount / 5000);
  return round(hours);
}

export function distanceMeters(lat1: number, lng1: number, lat2: number, lng2: number) {
  const radius = 6_371_000;
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad;
  const dLng = (lng2 - lng1) * rad;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * radius * Math.asin(Math.min(1, Math.sqrt(a)));
}

export function insideJobGeofence(ctx: Pick<FeatureContext, "lat" | "lng" | "siteLat" | "siteLng">, radius = 50) {
  const meters = distanceMeters(ctx.lat, ctx.lng, ctx.siteLat, ctx.siteLng);
  return { meters: round(meters), onSite: meters <= radius, radius };
}

export function travelMinutes(meters: number, kmh = 40) {
  const km = meters / 1000;
  return round((km / Math.max(kmh, 1)) * 60);
}

export function routeCost(meters: number, litersPer100: number, fuelPrice: number, toll = 0) {
  const liters = (meters / 1000 / 100) * litersPer100;
  const fuel = liters * fuelPrice;
  return { liters: round(liters), fuel: round(fuel), toll: round(toll), total: round(fuel + toll) };
}

export function vatBreakdown(gross: number, rate: number) {
  const allowed = rate === 10 || rate === 20 ? rate : 0;
  const net = gross / (1 + allowed / 100);
  const vat = gross - net;
  return { rate: allowed, net: round(net), vat: round(vat), gross: round(gross) };
}

export function withholding(amount: number, percent = 20) {
  const tax = round((amount * percent) / 100);
  return { base: round(amount), stopaj: tax, payable: round(amount - tax) };
}

export function balancedEntry(amount: number, debitAccount: string, creditAccount: string) {
  const value = round(Math.abs(amount));
  const debit = value;
  const credit = value;
  if (debit !== credit) throw new Error("Defter dengede değil");
  return {
    balanced: true,
    debit,
    credit,
    debitAccount,
    creditAccount,
  };
}

export function agingBuckets(amount: number) {
  return {
    d0: round(amount * 0.45),
    d30: round(amount * 0.3),
    d60: round(amount * 0.15),
    d90: round(amount * 0.1),
  };
}

export function profitMargin(revenue: number, cost: number) {
  const profit = round(revenue - cost);
  return { profit, marginPct: revenue > 0 ? round((profit / revenue) * 100) : 0 };
}

export function maintenanceDue(hours: number, interval = 30) {
  return {
    hours: round(hours),
    interval,
    due: hours >= interval,
    remaining: round(Math.max(0, interval - hours)),
  };
}

export function fuelPerHour(liters: number, hours: number) {
  if (hours <= 0) return 0;
  return round(liters / hours);
}

export function backoffMs(attempt: number) {
  const power = Math.max(0, Math.min(8, Math.floor(attempt)));
  return Math.min(60_000, 500 * 2 ** power);
}

export function fifoCost(layers: { qty: number; unit: number }[], take: number) {
  let left = take;
  let cost = 0;
  for (const layer of layers) {
    if (left <= 0) break;
    const qty = Math.min(layer.qty, left);
    cost += qty * layer.unit;
    left -= qty;
  }
  return { cost: round(cost), short: round(Math.max(0, left)) };
}

export function lifoCost(layers: { qty: number; unit: number }[], take: number) {
  return fifoCost([...layers].reverse(), take);
}

export function reorderPoint(dailyDemand: number, leadDays: number, safety: number) {
  return round(dailyDemand * leadDays + safety);
}

export function creditScore(invoiced: number, collected: number) {
  if (invoiced <= 0) return 70;
  const ratio = Math.min(1, Math.max(0, collected / invoiced));
  return Math.round(ratio * 100);
}

export function intervalsOverlap(aStart: number, aEnd: number, bStart: number, bEnd: number) {
  return aStart < bEnd && bStart < aEnd;
}

export function canAccess(role: string, module: EnterpriseModule) {
  if (role === "usta") return true;
  if (role === "muhasebe") return module === "finans" || module === "rapor";
  if (role === "cirak") return module === "ekipman" || module === "offline" || module === "crm";
  return module === "crm";
}

export function integrationFlags() {
  const env = import.meta.env as unknown as Record<string, string | undefined>;
  return {
    maps: Boolean(env["VITE_GOOGLE_MAPS_API_KEY"]),
    gemini: Boolean(env["VITE_GEMINI_API_KEY"]),
    vision: Boolean(env["VITE_GOOGLE_VISION_API_KEY"]),
  };
}

export async function enhanceWithGemini(text: string) {
  const env = import.meta.env as unknown as Record<string, string | undefined>;
  const key = env["VITE_GEMINI_API_KEY"];
  if (!key) return null;
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(key)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: `Saha notunu JSON özetle: ${text}` }] }],
      }),
    },
  );
  if (!response.ok) throw new Error("Gemini yanıt vermedi");
  const body = (await response.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  return body.candidates?.[0]?.content?.parts?.[0]?.text ?? null;
}

export async function signPayload(secret: string, body: string) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
  return [...new Uint8Array(signature)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function runEnterpriseFeature(feature: EnterpriseFeatureMeta, ctx: FeatureContext): FeatureResult {
  const slot = ((feature.id - 1) % 100) + 1;
  const data = metricsFor(feature.module, slot, ctx);
  const summary = Object.entries(data)
    .slice(0, 3)
    .map(([key, value]) => `${key}: ${String(value)}`)
    .join(" · ");
  return {
    id: feature.id,
    module: feature.module,
    title: feature.title,
    ok: true,
    summary: summary || feature.title,
    data,
  };
}

function metricsFor(module: EnterpriseModule, slot: number, ctx: FeatureContext): FeatureResult["data"] {
  if (module === "ai") return aiMetrics(slot, ctx);
  if (module === "filo") return fleetMetrics(slot, ctx);
  if (module === "finans") return financeMetrics(slot, ctx);
  if (module === "ekipman") return equipmentMetrics(slot, ctx);
  if (module === "offline") return offlineMetrics(slot, ctx);
  if (module === "guvenlik") return securityMetrics(slot, ctx);
  if (module === "stok") return stockMetrics(slot, ctx);
  if (module === "crm") return crmMetrics(slot, ctx);
  if (module === "rapor") return reportMetrics(slot, ctx);
  return platformMetrics(slot, ctx);
}

function aiMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const note = parseFieldNote(ctx.text);
  if (slot === 1) {
    return {
      amount: note.amount,
      method: note.method,
      when: note.when,
      action: note.action,
      customer: note.customerHint,
    };
  }
  if (slot === 3) return { priority: note.priority };
  if (slot === 7) return { hours: estimateJobHours(ctx.text, ctx.amount) };
  if (slot === 10) return { command: ctx.text.trim() ? "hazır" : "komut yok", tokens: estimateTokens(ctx.text) };
  return {
    tokens: estimateTokens(ctx.text),
    sentiment: sentimentScore(ctx.text),
    translated: translateFieldTerms(ctx.text).slice(0, 80),
    hours: estimateJobHours(ctx.text, ctx.amount),
    slot,
  };
}

function fleetMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const fence = insideJobGeofence(ctx);
  const minutes = travelMinutes(fence.meters);
  const cost = routeCost(fence.meters, 8, Math.max(ctx.rate, 1));
  if (slot === 3) return { meters: fence.meters, onSite: fence.onSite };
  if (slot === 4) return { min30: minutes <= 30, min45: minutes <= 45, min60: minutes <= 60, minutes };
  if (slot === 8) return { liters: cost.liters, fuel: cost.fuel, total: cost.total };
  return { meters: fence.meters, minutes, total: cost.total, slot };
}

function financeMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  if (slot === 1) {
    const entry = balancedEntry(ctx.amount, "Kasa", "Cari");
    return { balanced: entry.balanced, debit: entry.debit, credit: entry.credit };
  }
  if (slot === 2) {
    const tax = vatBreakdown(ctx.amount, ctx.rate);
    const stop = withholding(tax.net);
    return { net: tax.net, kdv: tax.vat, stopaj: stop.stopaj, payable: stop.payable };
  }
  if (slot === 4) return agingBuckets(ctx.amount);
  if (slot === 7) return { wage: round(ctx.hours * ctx.rate) };
  if (slot === 8) return profitMargin(ctx.amount, ctx.cost);
  const margin = profitMargin(ctx.amount, ctx.cost);
  return { profit: margin.profit, marginPct: margin.marginPct, score: Math.max(0, 100 - slot), slot };
}

function equipmentMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const due = maintenanceDue(ctx.hours, slot === 1 ? 30 : 30);
  return {
    due: due.due,
    remaining: due.remaining,
    litersPerHour: fuelPerHour(ctx.quantity, ctx.hours),
    repairVsReplace: ctx.cost > ctx.amount ? "değiştir" : "onar",
    slot,
  };
}

function offlineMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  return {
    backoffMs: backoffMs(ctx.attempt || slot),
    adaptive: ctx.attempt > 3,
    slot,
  };
}

function securityMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const role = ctx.text.trim() || "usta";
  return {
    allowed: canAccess(role, "finans"),
    pinLength: Math.min(ctx.text.length, 12),
    slot,
  };
}

function stockMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const layers = [
    { qty: Math.max(1, ctx.quantity), unit: Math.max(1, ctx.cost) },
    { qty: 4, unit: round(Math.max(1, ctx.cost) * 1.1) },
  ];
  const cost = slot % 2 === 0 ? lifoCost(layers, 2) : fifoCost(layers, 2);
  return {
    cogs: cost.cost,
    short: cost.short,
    reorder: reorderPoint(ctx.quantity || 1, 5, 2),
    slot,
  };
}

function crmMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const score = creditScore(ctx.amount, ctx.cost);
  const overlap = intervalsOverlap(ctx.hours, ctx.hours + 1, slot, slot + 0.5);
  return { credit: score, collision: overlap, balance: round(ctx.amount - ctx.cost), slot };
}

function reportMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const margin = profitMargin(ctx.amount, ctx.cost);
  return {
    revenue: round(ctx.amount),
    profit: margin.profit,
    marginPct: margin.marginPct,
    health: Math.max(0, Math.min(100, margin.marginPct)),
    slot,
  };
}

function platformMetrics(slot: number, ctx: FeatureContext): FeatureResult["data"] {
  const flags = integrationFlags();
  return {
    maps: flags.maps,
    gemini: flags.gemini,
    vision: flags.vision,
    backoffMs: backoffMs(ctx.attempt || 1),
    slot,
  };
}
