import { useState } from "react";
import { Share2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { formatTL } from "@/lib/finance";
import { shareReceiptViaWhatsApp, type ReceiptModel } from "@/lib/receipt";

export function ReceiptDocument({ model, pdf }: { model: ReceiptModel; pdf?: File }) {
  const [busy, setBusy] = useState(false);

  async function share() {
    setBusy(true);
    try {
      await shareReceiptViaWhatsApp(model, pdf);
      toast.success("Paylaşım penceresi açıldı. WhatsApp'ı seçin.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Makbuz paylaşılamadı");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="space-y-3">
      <article className="overflow-hidden rounded-2xl border bg-white text-zinc-900 shadow-sm">
        <header className="bg-teal-700 px-5 py-4 text-white">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xl font-bold tracking-tight">Saha Usta</p>
              <p className="text-[11px] uppercase tracking-[0.18em] text-teal-100">
                {model.kind === "payment" ? "Tahsilat fişi" : "İş makbuzu"}
              </p>
            </div>
            <div className="text-right text-xs leading-5">
              <p>No {model.receiptNo}</p>
              <p>{model.dateLabel}</p>
            </div>
          </div>
        </header>
        <div className="space-y-4 px-5 py-4">
          <div>
            <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400">Müşteri</p>
            <p className="text-lg font-semibold">{model.customerName}</p>
            {model.customerPhone && <p className="text-sm text-zinc-500">{model.customerPhone}</p>}
          </div>
          {model.note && <p className="text-sm text-zinc-600">{model.note}</p>}
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-[11px] uppercase tracking-wide text-zinc-400">
                <th className="py-2 font-medium">Yapılan işlem</th>
                <th className="py-2 text-right font-medium">Tutar</th>
              </tr>
            </thead>
            <tbody>
              {model.lines.map((line) => (
                <tr key={line.label} className="border-b border-zinc-100">
                  <td className="py-2">{line.label}</td>
                  <td className="py-2 text-right tabular-nums">{formatTL(line.amount)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td className="pt-3 font-semibold">Toplam</td>
                <td className="pt-3 text-right text-base font-bold tabular-nums text-teal-800">
                  {formatTL(model.total)}
                </td>
              </tr>
            </tfoot>
          </table>
          <p className="text-center text-xs text-zinc-400">Saha Usta · Teşekkür ederiz.</p>
        </div>
      </article>
      <Button className="w-full" disabled={busy} onClick={() => void share()}>
        <Share2 />
        WhatsApp ile paylaş
      </Button>
    </section>
  );
}
