import { useEffect } from "react";
import { scanWageAlerts } from "@/lib/alerts";
import { scanAppointmentAlerts } from "@/lib/appointments";
import { useRecords } from "@/lib/work";

/** Keeps hourly wage and appointment alarms running while the installed app is open. */
export function FieldAlerts() {
  const jobs = useRecords("job");

  useEffect(() => {
    const tick = () => {
      scanWageAlerts(jobs.data ?? []);
      scanAppointmentAlerts();
    };
    tick();
    const id = window.setInterval(tick, 5000);
    const onVisible = () => {
      if (document.visibilityState === "visible") tick();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", tick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", tick);
    };
  }, [jobs.data]);

  return null;
}
