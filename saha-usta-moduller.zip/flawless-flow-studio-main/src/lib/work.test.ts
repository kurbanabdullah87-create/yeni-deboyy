import {describe,it,expect} from 'vitest';
import {hourlyCharge,payrollAmount,payrollBalance,elapsedSeconds,depreciation} from './work';
describe('İş ve yevmiye kuralları',()=>{
 it('500 TL saatlik iş 30 dakikada 250 TL',()=>expect(hourlyCharge(1800,500)).toBe(250));
 it('tam gün 1500 TL',()=>expect(payrollAmount(1,1500,1)).toBe(1500));
 it('yarım gün 750 TL',()=>expect(payrollAmount(.5,1500,1)).toBe(750));
 it('çeyrek gün 375 TL',()=>expect(payrollAmount(.25,1500,1)).toBe(375));
 it('x1.5 mesai 2250 TL',()=>expect(payrollAmount(1,1500,1.5)).toBe(2250));
 it('x2 mesai 3000 TL',()=>expect(payrollAmount(1,1500,2)).toBe(3000));
 it('avans hakedişten düşülür',()=>expect(payrollBalance(5000,2000)).toBe(3000));
 it('duraklatılan süre sabit',()=>expect(elapsedSeconds({seconds:120},5000)).toBe(120));
 it('amortisman negatif olmaz',()=>expect(depreciation(1000,1,'2020-01-01',new Date('2026-01-01'))).toBe(0));
});