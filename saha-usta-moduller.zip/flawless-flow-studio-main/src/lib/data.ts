import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Expense, Tx } from "@/lib/finance";
import { DEFAULT_TEMPLATES } from "@/lib/templates";
import { haptic } from "@/lib/haptic";
import { cachedRead, persistWrite } from "@/lib/offline";

export interface Customer {
  id: string;
  name: string;
  phone: string | null;
  address: string | null;
  rating: number | null;
  notes: string | null;
  created_at: string;
  deleted_at?: string | null;
}

export interface Template {
  id: string;
  title: string;
  body: string;
}

function check<T>(r: { data: T | null; error: { message: string } | null }): T {
  if (r.error) throw new Error(r.error.message);
  return r.data as T;
}

export const useCustomers = () =>
  useQuery({
    queryKey: ["customers"],
    networkMode: "always",
    queryFn: () =>
      cachedRead(
        "customers",
        async () =>
          check(
            await supabase.from("customers").select("*").is("deleted_at", null).order("name"),
          ) as Customer[],
      ),
  });

export const useTransactions = () =>
  useQuery({
    queryKey: ["transactions"],
    networkMode: "always",
    queryFn: () => cachedRead("transactions", async () => {
      const rows = check(
        await supabase
          .from("transactions")
          .select("*")
          .is("deleted_at", null)
          .order("occurred_on", { ascending: false })
          .order("created_at", { ascending: false }),
      );
      return rows.map((r) => ({ ...r, amount: Number(r.amount), material_cost: Number(r.material_cost) })) as Tx[];
    }),
  });

export const useExpenses = () =>
  useQuery({
    queryKey: ["expenses"],
    networkMode: "always",
    queryFn: () => cachedRead("expenses", async () => {
      const rows = check(
        await supabase.from("expenses").select("*").is("deleted_at", null).order("occurred_on", { ascending: false }),
      );
      return rows.map((r) => ({ ...r, amount: Number(r.amount) })) as Expense[];
    }),
  });

export const useTemplates = () =>
  useQuery({
    queryKey: ["templates"],
    queryFn: async () => {
      let rows = check(await supabase.from("message_templates").select("id,title,body").order("created_at"));
      if (rows.length === 0) {
        rows = check(await supabase.from("message_templates").insert(DEFAULT_TEMPLATES).select("id,title,body"));
      }
      return rows as Template[];
    },
  });

type Table = "customers" | "transactions" | "expenses" | "message_templates";
const KEY: Record<Table, string> = {
  customers: "customers",
  transactions: "transactions",
  expenses: "expenses",
  message_templates: "templates",
};

export function useUpsert(table: Table) {
  const qc = useQueryClient();
  return useMutation({
    networkMode: "always",
    mutationFn: async (row: Record<string, unknown>) => {
      const { id, ...rest } = row;
      await persistWrite(table, id ? "update" : "insert", { ...rest, id: id ?? crypto.randomUUID() });
    },
    onSuccess: () => {
      haptic();
      qc.invalidateQueries({ queryKey: [KEY[table]] });
      if (table === "customers") qc.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Kaydedildi");
    },
    onError: (e: Error) => toast.error("Kaydedilemedi: " + e.message),
  });
}

/** Removes from view immediately, commits delete after 5s unless "Geri Al" is pressed. */
export function useUndoableDelete(table: Table) {
  const qc = useQueryClient();
  return (id: string, label = "Arşive alındı") => {
    haptic([10, 30, 10]);
    const key = [KEY[table]];
    const prev = qc.getQueryData<{ id: string }[]>(key);
    qc.setQueryData<{ id: string }[]>(key, (old) => old?.filter((r) => r.id !== id));
    let undone = false;
    const timer = setTimeout(async () => {
      if (undone) return;
      let error: { message: string } | null = null;
      try { await persistWrite(table, "delete", { id }); } catch (e) { error = { message: e instanceof Error ? e.message : "Silinemedi" }; }
      if (error) {
        toast.error("Silinemedi: " + error.message);
        if (prev) qc.setQueryData(key, prev);
      }
      qc.invalidateQueries({ queryKey: key });
      qc.invalidateQueries({ queryKey: ["archive"] });
      if (table === "customers") qc.invalidateQueries({ queryKey: ["transactions"] });
    }, 5000);
    toast(label, {
      duration: 5000,
      action: {
        label: "Geri Al",
        onClick: () => {
          undone = true;
          clearTimeout(timer);
          if (prev) qc.setQueryData(key, prev);
          haptic();
        },
      },
    });
  };
}

export type ArchiveTable = "customers" | "transactions" | "expenses" | "work_records";

export function useArchived(table: ArchiveTable) {
  return useQuery({
    queryKey: ["archive", table],
    networkMode: "always",
    queryFn: () =>
      cachedRead("archive:" + table, async () => {
        const rows = check(
          await supabase
            .from(table)
            .select("*")
            .not("deleted_at", "is", null)
            .order("deleted_at", { ascending: false }),
        );
        return (rows as { deleted_at: string | null }[]).filter((row) => row.deleted_at);
      }),
  });
}

export function useArchiveActions() {
  const qc = useQueryClient();
  return useMutation({
    networkMode: "always",
    mutationFn: async (input: {
      table: ArchiveTable;
      action: "restore" | "purge";
      row: object;
    }) => {
      const raw = input.row as Record<string, unknown>;
      if (input.action === "purge") {
        await persistWrite(input.table, "purge", { id: raw["id"], kind: raw["kind"] });
        return;
      }
      await persistWrite(input.table, "update", { ...raw, deleted_at: null });
    },
    onSuccess: () => {
      haptic();
      qc.invalidateQueries({ queryKey: ["archive"] });
      qc.invalidateQueries({ queryKey: ["customers"] });
      qc.invalidateQueries({ queryKey: ["transactions"] });
      qc.invalidateQueries({ queryKey: ["expenses"] });
      qc.invalidateQueries({ queryKey: ["work"] });
      toast.success("Arşiv güncellendi");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}
