import { describe, expect, it } from "vitest";
import { APPOINTMENT_LEAD_MS, shouldAlertAppointment, shouldAlertWageHour } from "./alerts";

describe("yevmiye ve randevu uyarıları", () => {
  it("bir saat dolmadan yevmiye uyarısı vermez", () => {
    expect(shouldAlertWageHour(3599, 0)).toBe(false);
  });
  it("tam bir saatte yevmiye uyarısı verir", () => {
    expect(shouldAlertWageHour(3600, 0)).toBe(true);
  });
  it("aynı saati tekrar uyarmaz", () => {
    expect(shouldAlertWageHour(4000, 1)).toBe(false);
  });
  it("her yeni saatte yeniden uyarır", () => {
    expect(shouldAlertWageHour(7200, 1)).toBe(true);
  });
  it("randevuya tam 10 dakika kala uyarır", () => {
    expect(shouldAlertAppointment(APPOINTMENT_LEAD_MS, false)).toBe(true);
  });
  it("10 dakikadan önce uyarmaz", () => {
    expect(shouldAlertAppointment(APPOINTMENT_LEAD_MS + 1, false)).toBe(false);
  });
  it("uyarılmış randevuyu tekrarlamaz", () => {
    expect(shouldAlertAppointment(60_000, true)).toBe(false);
  });
});
