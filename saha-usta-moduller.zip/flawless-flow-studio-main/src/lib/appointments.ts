import { buzzAndNotify, shouldAlertAppointment } from "@/lib/alerts";

const KEY = "saha-appointments-v1";

export interface Appointment {
  id: string;
  customerName: string;
  at: string;
  detail: string;
  alertedAt?: string | null;
}

export function loadAppointments(): Appointment[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const rows = JSON.parse(localStorage.getItem(KEY) || "[]") as Appointment[];
    return Array.isArray(rows) ? rows : [];
  } catch {
    return [];
  }
}

export function saveAppointments(items: Appointment[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new Event("saha-appointments"));
}

export function scanAppointmentAlerts(now = Date.now()) {
  const items = loadAppointments();
  let changed = false;
  for (const item of items) {
    const start = Date.parse(item.at);
    if (Number.isNaN(start)) continue;
    if (!shouldAlertAppointment(start - now, Boolean(item.alertedAt))) continue;
    item.alertedAt = new Date(now).toISOString();
    changed = true;
    void buzzAndNotify(
      "Randevuya 10 dakika kaldı",
      `${item.customerName} · ${item.detail || "İş detayı yok"}`,
      `appt-${item.id}`,
    );
  }
  if (changed) saveAppointments(items);
}
