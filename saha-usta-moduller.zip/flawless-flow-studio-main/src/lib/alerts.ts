import { elapsedSeconds, type Payload } from "@/lib/work";

export const APPOINTMENT_LEAD_MS = 10 * 60 * 1000;
const WAGE_KEY = "saha-wage-alerted-hours";

export function shouldAlertWageHour(seconds: number, lastHour: number) {
  const hour = Math.floor(seconds / 3600);
  return hour >= 1 && hour > lastHour;
}

/** True once the visit is 10 minutes away, until shortly after it starts. */
export function shouldAlertAppointment(leadMs: number, alreadyAlerted: boolean) {
  return !alreadyAlerted && leadMs <= APPOINTMENT_LEAD_MS && leadMs > -2 * 60 * 1000;
}

export async function ensureNotifyPermission() {
  if (typeof Notification === "undefined") return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  try {
    return (await Notification.requestPermission()) === "granted";
  } catch {
    return false;
  }
}

export async function buzzAndNotify(title: string, body: string, tag: string) {
  try {
    navigator.vibrate?.([200, 100, 200, 100, 400]);
  } catch {
    /* ignore */
  }
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  const options = { body, tag, renotify: true } as NotificationOptions;
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) {
      await reg.showNotification(title, options);
      return;
    }
  } catch {
    /* fall through to the page Notification */
  }
  try {
    new Notification(title, options);
  } catch {
    /* ignore */
  }
}

export function scanWageAlerts(records: { id: string; payload: Payload }[], now = Date.now()) {
  if (typeof localStorage === "undefined") return;
  let map: Record<string, number> = {};
  try {
    map = JSON.parse(localStorage.getItem(WAGE_KEY) || "{}") as Record<string, number>;
  } catch {
    map = {};
  }
  let changed = false;
  for (const record of records) {
    if (!record.payload.started_at) continue;
    const seconds = elapsedSeconds(record.payload, now);
    const hour = Math.floor(seconds / 3600);
    const last = Number(map[record.id] ?? 0);
    if (!shouldAlertWageHour(seconds, last)) continue;
    map[record.id] = hour;
    changed = true;
    const title = record.payload.title ? String(record.payload.title) : "İş";
    void buzzAndNotify(
      "1 Saat Doldu - Yevmiye kontrolü yapın",
      `${title}: ${hour}. saat doldu.`,
      `wage-${record.id}-${hour}`,
    );
  }
  if (changed) localStorage.setItem(WAGE_KEY, JSON.stringify(map));
}
