import type { Customer } from "@/lib/data";
import { formatDate, formatTL, profitBreakdown, type Tx } from "@/lib/finance";

let fontCache: { regular: string; bold: string } | null = null;

async function toBase64(url: string) {
  const buf = await (await fetch(url)).arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

/** Builds a receipt PDF for a job/payment with full account summary. */
export async function buildReceipt(opts: { business: string; customer: Customer; tx: Tx; balance: number }) {
  const { customer, tx, balance } = opts;
  const { jsPDF } = await import("jspdf");
  if (!fontCache) {
    const [regular, bold] = await Promise.all([toBase64("/fonts/DejaVuSans.ttf"), toBase64("/fonts/DejaVuSans-Bold.ttf")]);
    fontCache = { regular, bold };
  }
  const doc = new jsPDF({ unit: "mm", format: "a5" });
  doc.addFileToVFS("DejaVu.ttf", fontCache.regular);
  doc.addFont("DejaVu.ttf", "DejaVu", "normal");
  doc.addFileToVFS("DejaVu-Bold.ttf", fontCache.bold);
  doc.addFont("DejaVu-Bold.ttf", "DejaVu", "bold");

  const W = doc.internal.pageSize.getWidth();
  const no = tx.id.slice(0, 8).toUpperCase();

  doc.setFillColor(20, 184, 166);
  doc.rect(0, 0, W, 28, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("DejaVu", "bold");
  doc.setFontSize(16);
  doc.text(opts.business, 12, 13);
  doc.setFont("DejaVu", "normal");
  doc.setFontSize(9);
  doc.text(tx.kind === "debt" ? "İŞ MAKBUZU" : "TAHSİLAT MAKBUZU", 12, 21);
  doc.text(`No: ${no}`, W - 12, 13, { align: "right" });
  doc.text(formatDate(tx.occurred_on), W - 12, 21, { align: "right" });

  doc.setTextColor(30, 30, 30);
  let y = 40;
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text("MÜŞTERİ", 12, y);
  doc.setTextColor(30, 30, 30);
  doc.setFont("DejaVu", "bold");
  doc.setFontSize(12);
  doc.text(customer.name, 12, y + 6);
  doc.setFont("DejaVu", "normal");
  doc.setFontSize(9);
  if (customer.phone) doc.text(customer.phone, 12, y + 12);
  if (customer.address) doc.text(doc.splitTextToSize(customer.address, W - 24), 12, y + 17);

  y = 72;
  doc.setDrawColor(220, 220, 220);
  doc.line(12, y, W - 12, y);
  y += 8;
  const row = (label: string, value: string, bold = false) => {
    doc.setFont("DejaVu", bold ? "bold" : "normal");
    doc.text(label, 12, y);
    doc.text(value, W - 12, y, { align: "right" });
    y += 7;
  };
  doc.setFontSize(10);
  if (tx.description) {
    doc.setFont("DejaVu", "normal");
    doc.text(doc.splitTextToSize(tx.description, W - 24), 12, y);
    y += 10;
  }
  if (tx.kind === "debt") {
    const pb = profitBreakdown(tx.amount, tx.material_cost, tx.vat_rate);
    if (tx.material_cost > 0) row("Malzeme", formatTL(tx.material_cost));
    row("İşçilik", formatTL(Math.max(0, pb.netOfVat - tx.material_cost)));
    if (tx.vat_rate > 0) row(`KDV (%${tx.vat_rate})`, formatTL(pb.vat));
    row("TOPLAM", formatTL(tx.amount), true);
  } else {
    row(`Ödeme (${tx.method ?? "Nakit"})`, formatTL(tx.amount), true);
  }
  y += 4;
  doc.line(12, y, W - 12, y);
  y += 8;
  doc.setFontSize(11);
  row("Kalan bakiye", formatTL(balance), true);

  doc.setFontSize(8);
  doc.setTextColor(140, 140, 140);
  doc.text("Teşekkür ederiz.", W / 2, doc.internal.pageSize.getHeight() - 10, { align: "center" });

  const blob = doc.output("blob");
  const file = new File([blob], `makbuz-${no}.pdf`, { type: "application/pdf" });
  return file;
}

export interface ReceiptLine {
  label: string;
  amount: number;
}

export interface ReceiptModel {
  customerName: string;
  customerPhone?: string | null;
  dateLabel: string;
  receiptNo: string;
  kind: "debt" | "payment";
  lines: ReceiptLine[];
  total: number;
  note?: string | null;
}

export function receiptModelFromTx(customer: Customer, tx: Tx): ReceiptModel {
  const lines: ReceiptLine[] = [];
  if (tx.kind === "debt") {
    const pb = profitBreakdown(tx.amount, tx.material_cost, tx.vat_rate);
    if (tx.material_cost > 0) lines.push({ label: "Malzeme", amount: tx.material_cost });
    lines.push({ label: "İşçilik", amount: Math.max(0, roundMoney(pb.netOfVat - tx.material_cost)) });
    if (tx.vat_rate > 0) lines.push({ label: `KDV (%${tx.vat_rate})`, amount: pb.vat });
  } else {
    lines.push({ label: `Tahsilat (${tx.method ?? "Nakit"})`, amount: tx.amount });
  }
  return {
    customerName: customer.name,
    customerPhone: customer.phone,
    dateLabel: formatDate(tx.occurred_on),
    receiptNo: tx.id.slice(0, 8).toUpperCase(),
    kind: tx.kind,
    lines,
    total: tx.amount,
    note: tx.description ?? null,
  };
}

function roundMoney(n: number) {
  return Math.round(n * 100) / 100;
}

export async function renderReceiptPng(model: ReceiptModel) {
  const width = 720;
  const height = 460 + model.lines.length * 42;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Makbuz görseli oluşturulamadı");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = "#0f766e";
  ctx.fillRect(0, 0, width, 128);
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 40px Segoe UI, Arial, sans-serif";
  ctx.fillText("Saha Usta", 36, 58);
  ctx.font = "16px Segoe UI, Arial, sans-serif";
  ctx.fillText(model.kind === "payment" ? "TAHSİLAT FİŞİ" : "İŞ MAKBUZU", 36, 94);
  ctx.textAlign = "right";
  ctx.fillText(`No ${model.receiptNo}`, width - 36, 54);
  ctx.fillText(model.dateLabel, width - 36, 88);
  ctx.textAlign = "left";
  ctx.fillStyle = "#71717a";
  ctx.font = "13px Segoe UI, Arial, sans-serif";
  ctx.fillText("MÜŞTERİ", 36, 172);
  ctx.fillStyle = "#18181b";
  ctx.font = "bold 26px Segoe UI, Arial, sans-serif";
  ctx.fillText(model.customerName, 36, 208);
  ctx.font = "16px Segoe UI, Arial, sans-serif";
  ctx.fillStyle = "#3f3f46";
  if (model.customerPhone) ctx.fillText(model.customerPhone, 36, 238);
  if (model.note) {
    ctx.fillText(model.note.slice(0, 80), 36, 268);
  }
  let y = 320;
  ctx.strokeStyle = "#e4e4e7";
  ctx.beginPath();
  ctx.moveTo(36, y);
  ctx.lineTo(width - 36, y);
  ctx.stroke();
  y += 40;
  for (const line of model.lines) {
    ctx.fillStyle = "#27272a";
    ctx.textAlign = "left";
    ctx.fillText(line.label, 36, y);
    ctx.textAlign = "right";
    ctx.fillText(formatTL(line.amount), width - 36, y);
    y += 42;
  }
  ctx.beginPath();
  ctx.moveTo(36, y - 16);
  ctx.lineTo(width - 36, y - 16);
  ctx.stroke();
  ctx.fillStyle = "#0f766e";
  ctx.font = "bold 22px Segoe UI, Arial, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("TOPLAM", 36, y + 20);
  ctx.textAlign = "right";
  ctx.fillText(formatTL(model.total), width - 36, y + 20);
  ctx.textAlign = "center";
  ctx.fillStyle = "#a1a1aa";
  ctx.font = "14px Segoe UI, Arial, sans-serif";
  ctx.fillText("Saha Usta · Teşekkür ederiz.", width / 2, height - 28);
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((file) => (file ? resolve(file) : reject(new Error("Makbuz görseli oluşturulamadı"))), "image/png");
  });
  return new File([blob], `saha-usta-makbuz-${model.receiptNo}.png`, { type: "image/png" });
}

export async function shareReceiptViaWhatsApp(model: ReceiptModel, pdf?: File) {
  const image = await renderReceiptPng(model);
  const text = `Saha Usta makbuz — ${model.customerName} — ${formatTL(model.total)}`;
  const bundles = pdf ? [[image, pdf], [image], [pdf]] : [[image]];
  const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
  for (const files of bundles) {
    const data: ShareData = { files, title: "Saha Usta Makbuz", text };
    if (!nav.canShare?.(data)) continue;
    try {
      await navigator.share(data);
      return;
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
    }
  }
  await shareOrDownload(image);
  if (pdf) await shareOrDownload(pdf);
}

export async function shareOrDownload(file: File) {
  const nav = navigator as Navigator & { canShare?: (d: { files: File[] }) => boolean };
  if (nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({ files: [file], title: file.name });
      return;
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
    }
  }
  const url = URL.createObjectURL(file);
  const a = document.createElement("a");
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
