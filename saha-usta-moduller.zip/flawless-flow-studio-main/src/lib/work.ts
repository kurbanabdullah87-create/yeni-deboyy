import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { cachedRead, persistWrite } from '@/lib/offline';

export type WorkKind = 'job' | 'payroll' | 'advance' | 'equipment' | 'maintenance' | 'shopping' | 'job_template' | 'settings';
export type Payload = Record<string, string | number | boolean | null | undefined> & {seconds?: string | number | boolean | null | undefined; started_at?: string | number | boolean | null | undefined; business?: string | number | boolean | null | undefined; status?: string | number | boolean | null | undefined; date?: string | number | boolean | null | undefined; title?: string | number | boolean | null | undefined; customer_id?: string | number | boolean | null | undefined; address?: string | number | boolean | null | undefined; hourly_rate?: string | number | boolean | null | undefined; price?: string | number | boolean | null | undefined; billed?: string | number | boolean | null | undefined; notes?: string | number | boolean | null | undefined; material_cost?: string | number | boolean | null | undefined; vat_rate?: string | number | boolean | null | undefined; days?: string | number | boolean | null | undefined; rate?: string | number | boolean | null | undefined; multiplier?: string | number | boolean | null | undefined; amount?: string | number | boolean | null | undefined; site?: string | number | boolean | null | undefined; name?: string | number | boolean | null | undefined; borrower?: string | number | boolean | null | undefined; borrowed_on?: string | number | boolean | null | undefined; last_service_seconds?: string | number | boolean | null | undefined; maintenance_hours?: string | number | boolean | null | undefined; purchased?: string | number | boolean | null | undefined; years?: string | number | boolean | null | undefined; code?: string | number | boolean | null | undefined; equipment_id?: string | number | boolean | null | undefined; cost?: string | number | boolean | null | undefined; done?: string | number | boolean | null | undefined; target?: string | number | boolean | null | undefined; owner_id?: string | number | boolean | null | undefined;};
export interface WorkRecord { id: string; owner_id: string; team_id: string; kind: WorkKind; payload: Payload; created_at: string; deleted_at?: string | null; }
export function useRecords(kind: WorkKind) {
  return useQuery({networkMode:'always',queryKey:['work',kind],queryFn:() => cachedRead('work:'+kind, async () => {
    const {data,error}=await supabase.from('work_records').select('*').eq('kind',kind).is('deleted_at', null).order('created_at',{ascending:false});
    if(error) throw error; return (data as unknown as WorkRecord[]).filter((row) => !row.deleted_at);
  })});
}
export function useArchiveRecord() {
  const qc = useQueryClient();
  return async (record: { id: string; kind: string }) => {
    try {
      await persistWrite("work_records", "delete", { id: record.id, kind: record.kind });
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["work"] }),
        qc.invalidateQueries({ queryKey: ["archive"] }),
      ]);
      toast.success("Arşive alındı");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Arşive alınamadı");
    }
  };
}
export function useSaveRecord(kind: WorkKind) {
 const qc=useQueryClient();
 return useMutation({networkMode:'always',mutationFn: async (row:{id?:string | undefined;owner_id?:string | undefined;payload:Payload}) => {
   const {data}=await supabase.auth.getSession(); if(!data.session) throw new Error('Oturum gerekli');
   const id=row.id??crypto.randomUUID();
   await persistWrite('work_records',row.id?'update':'insert',{...row,owner_id:row.owner_id??data.session.user.id,id,kind,payload:row.payload}); return id;
 },onSuccess:()=>{qc.invalidateQueries({queryKey:['work']});toast.success('Kaydedildi');},onError:(e:Error)=>toast.error(e.message)});
}
export function elapsedSeconds(p:Payload, now=Date.now()) {
 return Math.max(0,Number(p.seconds??0)+(p.started_at?Math.max(0,(now-Date.parse(String(p.started_at)))/1000):0));
}
export function hourlyCharge(seconds:number,rate:number) { return Math.round(seconds/3600*rate*100)/100; }
export function payrollAmount(days:number,rate:number,multiplier:number) {
 if(![1,.5,.25].includes(days)||![1,1.5,2].includes(multiplier)||rate<0) throw new Error('Geçersiz yevmiye');
 return Math.round(days*rate*multiplier*100)/100;
}
export function payrollBalance(earned:number,advances:number) {return Math.round((earned-advances)*100)/100;}
export function depreciation(price:number,years:number,purchased:string,now=new Date()) {
 const age=Math.max(0,(now.getTime()-new Date(purchased+'T00:00:00').getTime())/(365.25*86400000));
 return Math.round(Math.max(0,price*(1-age/Math.max(1,years)))*100)/100;
}
export function pageHead(title:string,description:string) {return {meta:[{title:title+' — Saha'},{name:'description',content:description},{property:'og:title',content:title+' — Saha'},{property:'og:description',content:description},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary'}]};}