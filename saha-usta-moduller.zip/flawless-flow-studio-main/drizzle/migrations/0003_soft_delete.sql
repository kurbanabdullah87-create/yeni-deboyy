ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.expenses ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
ALTER TABLE public.work_records ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

CREATE INDEX IF NOT EXISTS customers_active_idx ON public.customers (team_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS transactions_active_idx ON public.transactions (team_id, occurred_on) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS expenses_active_idx ON public.expenses (team_id, occurred_on) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS work_records_active_idx ON public.work_records (team_id, kind) WHERE deleted_at IS NULL;

DROP INDEX IF EXISTS public.transactions_job_record_unique;
CREATE UNIQUE INDEX transactions_job_record_unique ON public.transactions (job_record_id)
  WHERE job_record_id IS NOT NULL AND deleted_at IS NULL;

CREATE OR REPLACE FUNCTION public.bill_job(_job_id uuid) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE j public.work_records; c public.customers; result uuid; seconds numeric; amount numeric;
BEGIN
 IF NOT public.is_team_usta() THEN RAISE EXCEPTION 'Yetkisiz'; END IF;
 SELECT * INTO j FROM public.work_records WHERE id=_job_id AND team_id=public.current_team() AND kind='job' AND deleted_at IS NULL FOR UPDATE;
 IF j.id IS NULL THEN RAISE EXCEPTION 'İş bulunamadı'; END IF;
 SELECT id INTO result FROM public.transactions WHERE job_record_id=j.id AND deleted_at IS NULL;
 IF result IS NOT NULL THEN RETURN result; END IF;
 SELECT * INTO c FROM public.customers WHERE id=(j.payload->>'customer_id')::uuid AND team_id=public.current_team() AND deleted_at IS NULL;
 IF c.id IS NULL THEN RAISE EXCEPTION 'Müşteri seçin'; END IF;
 seconds:=coalesce((j.payload->>'seconds')::numeric,0);
 IF j.payload->>'started_at' IS NOT NULL THEN seconds:=seconds+greatest(0,extract(epoch FROM now()-(j.payload->>'started_at')::timestamptz)); END IF;
 amount:=CASE WHEN coalesce((j.payload->>'hourly_rate')::numeric,0)>0 THEN round(seconds/3600*(j.payload->>'hourly_rate')::numeric,2) ELSE coalesce((j.payload->>'price')::numeric,0) END;
 IF amount<=0 THEN RAISE EXCEPTION 'İş tutarı sıfır olamaz'; END IF;
 INSERT INTO public.transactions(customer_id,kind,amount,description,material_cost,vat_rate,job_record_id) VALUES(c.id,'debt',amount,j.payload->>'title',coalesce((j.payload->>'material_cost')::numeric,0),coalesce((j.payload->>'vat_rate')::smallint,0),j.id) RETURNING id INTO result;
 UPDATE public.work_records SET payload=payload||jsonb_build_object('status','Tamamlandı','seconds',seconds,'started_at',null,'billed',true),updated_at=now() WHERE id=j.id;
 RETURN result;
END; $$;
