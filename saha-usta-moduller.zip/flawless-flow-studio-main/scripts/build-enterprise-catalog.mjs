import { writeFileSync } from "node:fs";

const modules = [
  ["ai", 1],
  ["filo", 101],
  ["finans", 201],
  ["ekipman", 301],
  ["offline", 401],
  ["guvenlik", 501],
  ["stok", 601],
  ["crm", 701],
  ["rapor", 801],
  ["platform", 901],
];

const headlines = {
  ai: [
    "Gemini çok modlu saha notu ayrıştırıcı",
    "Sesle iş ve tahsilat doldurma",
    "Fotoğraflı iş önceliklendirme",
    "Ekipman ve usta eşleştirme",
    "Saha kılavuzu soru-cevap",
    "Fiş ve fatura okuma",
    "İş süresi tahmini",
    "Müşteri durum mesajı üretimi",
    "İş öncesi risk listesi",
    "Sesle eller serbest komut",
  ],
  filo: [
    "Canlı saha konum panosu",
    "Çok duraklı rota sıralama",
    "50 metre saha giriş-çıkış",
    "30-45-60 dakika hizmet alanı",
    "Eğim ve arazi profili",
    "Sokak görünümü ön izleme",
    "Çevrimdışı harita bağlantısı",
    "Yakıt ve geçiş maliyeti",
    "Müşteri yoğunluk haritası",
    "Bölge iş kümeleme",
  ],
  finans: [
    "Çift taraflı yevmiye fişi",
    "KDV ve stopaj hesabı",
    "Döviz çevrimi",
    "30-60-90 gün nakit görünümü",
    "Borç yaşlandırma",
    "Gider fişi sınıflama",
    "Yevmiye ve mesai hesabı",
    "İş kârlılığı",
    "Hakediş takibi",
    "IBAN makbuz toplamı",
  ],
  ekipman: [
    "30 saat bakım uyarısı",
    "Ekipman sayaç özeti",
    "Kalan ömür tahmini",
    "Makine defteri",
    "Yedek parça sayımı",
    "Zimmet teslimi",
    "Garanti bitiş kontrolü",
    "Saatlik yakıt denetimi",
    "Arıza çağrısı",
    "Onar veya değiştir",
  ],
  offline: [
    "Çevrimdışı kayıt kuyruğu",
    "PWA kurulum durumu",
    "Artan beklemeli yeniden deneme",
    "Anında arayüz, sonra sunucu",
    "Önbellek sürümü",
    "Yerel kayıt koruması",
    "Zayıf ağda sade yükleme",
    "Sekmeler arası eşitleme",
    "Hata sınırı kaydı",
    "Depolama kotası",
  ],
  guvenlik: [
    "Passkey ile giriş hazırlığı",
    "PIN cihaz kilidi",
    "Rol yetki matrisi",
    "Yerel kasa notu",
    "Bu cihazın yerel kaydını temizle",
    "İşlem denetim izi",
    "İzinli adres uyarısı",
    "Bilinen cihaz kaydı",
    "İkinci adım hatırlatması",
    "Ekip katılım kodu",
  ],
  stok: [
    "Depo ve araç stok özeti",
    "Yeniden sipariş noktası",
    "Barkod sayımı",
    "FIFO maliyet",
    "Tedarikçi kartı",
    "Mal kabul farkı",
    "Son kullanma uyarısı",
    "Araçlar arası teslim",
    "Fire kaydı",
    "Stok değeri",
  ],
  crm: [
    "Müşteri 360 özeti",
    "Hizmet talebi kartı",
    "Randevu mesaj taslağı",
    "Memnuniyet notu",
    "Sözleşme yenileme",
    "Müşteri etiketi",
    "Teklif hunisi",
    "İş teslim notu",
    "İletişim zaman çizelgesi",
    "Kredi skoru",
    "Randevu defteri",
    "Çakışan randevu kontrolü",
    "Randevuda cari bakiye",
  ],
  rapor: [
    "Günlük yönetici özeti",
    "Ölçü seçerek rapor",
    "Gelir tahmini",
    "Usta verim kartı",
    "Bölge gelir özeti",
    "Makine maliyet özeti",
    "Malzeme fire oranı",
    "Vergi dönemi özeti",
    "Zamanlanmış rapor",
    "Nakit sapma uyarısı",
  ],
  platform: [
    "Dış sorgu sözleşmesi",
    "Olay bildirimi imzası",
    "Takvim eşitleme hazırlığı",
    "Zamanlanmış iş kaydı",
    "Özellik bayrağı",
    "Muhasebe dışa aktarma satırı",
    "Mesaj kanalı yedeği",
    "Yedek alma kontrol listesi",
    "Ortam anahtarı durumu",
    "API deneme kartı",
  ],
};

const extras = {
  ai: "prompt önbelleği, jeton maliyeti, yerel yedek çözümleme, çok turlu bağlam, saha günlüğü çevirisi, duygu analizi, ihtilaf metni, sözlü onay, garanti talebi, vardiya devir özeti, kılavuz parçalama, geçmiş iş araması, vergi metni, nakit darboğaz uyarısı, sözleşme maddesi, fiyat önerisi, güvenlik brifingi, gider sınıflama, stok tükenme uyarısı, yorum isteği, bildirim metni, çakışma önerisi, performans yazısı, eğitim kartı, sipariş e-postası, feragat metni, fotoğraf etiketi, aday puanı, garanti bitişi, pazarlama cümlesi, iletişim özeti, delil paketi, arıza açıklaması, sayım asistanı, vergi indirimi, taşeron değerlendirme, risk planı, amortisman yazısı, iş ilanı, ayrılma riski, zimmet kaydı, tedarik fiyatı, hibe taraması, denetim dosyası, sigorta anlatısı, tahsilat planı, olay kaydı, çevre etkisi, enerji denetimi, politika metni, kurul özeti, yatırımcı notu, ortaklık taslağı, itibar notu, pazar özeti, rakip fiyat, paket önerisi, sadakat kademesi, yönlendirme kuralı, tutundurma teklifi, geri bildirim özeti, özellik isteği, sürüm notu, geliştirici notu, entegrasyon sağlığı, yama planı, uyum listesi, gizlilik etkisi, felaket planı, altyapı maliyeti, sorgu planı, önbellek oranı, gecikme, paket boyutu, bellek, ağ tasarrufu, pil tasarrufu, depolama sıkıştırma, eşitleme çatışması, titreşim deseni, konum izleyici, ağ tipi, pil durumu, pano, uyanık tutma, tam ekran, paylaşım, bildirim rozeti",
  filo: "hız sınırı uyarısı, rölanti süresi, iz kaydı, rota sapması, adres düzeltme, varış süresi, en yakın usta, konvoy, acil konum, park noktası, hava katmanı, eğim katmanı, saha fotoğraf konumu, özel iğne, KML dışa aktarma, çok depo, akaryakıt istasyonu, şarj noktası, gabari uyarısı, köprü ağırlığı, tek yön, yasak bölge, feribot saati, toprak yol, gece modu, uydu görüntüsü, trafik ısısı, sel riski, rüzgar yönü, ilaç sürüklenmesi, drone hattı, gölge analizi, sulama hattı, kablo hendeği, kuyu verimi, otlatma dönüşü, çit denetimi, zararlı odağı, gübre bölgesi, hasat ısısı, sera bölgesi, soğuk oda, kovan, orman envanteri, erozyon, havza, yaban geçişi, heyelan, yeraltı suyu, gürültü, hava kalitesi, kaçak döküm, kirlenme, sıkışma, hastalık yayılımı, don riski, dolu alanı, kuraklık, mera kapasitesi, karbon, biyoçeşitlilik, yenilenebilir potansiyel, mikro iklim, sis, buz, çamur, toz, kül, tahliye, deprem yarıçapı, yangın çevresi, taşkın, çığ, obruk, kıyı erozyonu, gelgit, nehir seviyesi, rezervuar, kanal debisi, baraj sızıntısı, set, drenaj, foseptik, direk envanteri, boru hattı, fiber, kapsama gölgesi",
  finans: "banka ekstresi eşleme, kasa, komisyon oranı, temettü, amortisman planı, kredi taksit, garanti karşılığı, şüpheli alacak, şirket içi virman, rotatif limit, kasa fişi, damga vergisi, stopaj bildirimi, bilanço, gelir tablosu, mizan, maliyet merkezi, bütçe sapması, başabaş, yatırım getirisi, likidite, borç ödeme gücü, işletme sermayesi, stok devir, alacak devir, nakit döngüsü, FAVÖK, serbest nakit, mali skor, mükerrer ödeme, çift onay, satınalma eşleme, cari limit, iskonto, prim, ikramiye, kıdem karşılığı, izin tahakkuku, araç km, kira artışı, abonelik, hukuk gideri, hibe kullanımı, gümrük, navlun, fire değeri, iade, eğitim yatırımı, personel borcu, avans mahsup, icra kesintisi, sendika aidatı, BES, yemek kartı, yol yardımı, telefon, koruyucu donanım, makine yenileme fonu, acil rezerv, kurumlar vergisi taksiti",
  ekipman: "hidrolik basınç, lastik basıncı, yağ ömrü, hararet, şarj voltajı, marş akımı, hava filtresi, egzoz ısısı, turbo, şanzıman ısısı, balata, akü sağlığı, enjektör, kızdırma bujisi, fan rolesi, ateşleme, kam mili, titreşim, yağ pompası, devirdaim, yakıt filtresi, keçe kaçağı, kuyruk mili, diferansiyel, aks yükü, rölanti oranı, soğuk çalıştırma, toz yutma, termal kamera, yağ analizi, kayış hizası, rulman ısısı, zincir gergisi, kavrama kalınlığı, şaft boşluğu, vinç halatı, bom açısı, kova diş, palet gergisi, kırıcı vuruş, burgu tork, bıçak keskinliği, oluk tıkanması, yakıt kapağı, kabin filtresi, klima kavrama, silecek akımı, korna, aydınlatma, ikaz lambası, kamera, ultrasonik engel, eğim açısı, devrilme koruması, uzaktan stop",
  offline: "servis çalışanı güncellemesi, çevrimdışı sayfa, arka plan indirme, periyodik eşitleme, paylaşım hedefi, kısayol, rozet, ekran uyanık, tam ekran, titreşim, düşük pil, veri tasarrufu, ortam denetimi, yazıcı, usb tanı, seri port, nfc etiket, rehber aktarımı, biyometrik giriş, ödeme sayfası, imza, şema sürümü, yedek json, geri yükleme, seçici eşitleme, bant ölçümü, çevrimdışı arama, bulanık arama, arka plan indeks, bellek, sanal liste, sonsuz kaydırma, yenile çek, kaydırma eylemi, uzun basış, pano, yakınlaştırma, klavye kısayolu, erişilebilir etiket, yüksek karşıtlık, yazı boyutu, azaltılmış hareket, odak kilidi, iş parçacığı, yayın kanalı, websocket yeniden bağlanma, istek tekrarı, önbellek süresi, hız sınırı, yük sıkıştırma, görsel sıkıştırma, kritik css, kod bölme, ölü kod, animasyon karesi",
  guvenlik: "oturum yenileme, çerez politikası, csrf başlığı, metin temizleme, parametreli sorgu, içerik güvenlik politikası, taşıma güvenliği, köken kısıtı, istek sınırı, giriş kilidi, parola karmaşıklığı, parola süresi, eski parola yasağı, kilit bildirimi, yönetici jetonu, dosya özeti, güvenli bağlantı, imzalı çerez, sosyal giriş, kurumsal sso, dizin eşitleme, anahtar dönüşümü, gizli kasa, sıfır güven, kişisel veri maskesi, unutulma hakkı, saklama süresi, açık rıza, olay kaydı, zafiyet listesi, sızma kontrol listesi, bağımlılık denetimi, malzeme listesi, sertifika süresi, dnssec, e-posta kimliği, yedek doğrulama, değişmez defter, iş sürekliliği, iso kontrol, denetim paketi",
  stok: "sayım turu, abc sınıfı, ekonomik sipariş, emniyet stoku, tedarik süresi, zamanında teslim, fiyat farkı, iade yetkisi, konsinye, çapraz sevkiyat, raf yerleşimi, toplama rotası, paket fişi, palet adresi, seri no, lot, güvenlik formu, sıcaklık, nem, kafes girişi, forklift bakım, raf kapasitesi, vinç defteri, rampa takvimi, taşıyıcı puanı, konşimento, gümrük arşivi, konteyner, demuraj, ambalaj firesi, tehlikeli atık, hurda geliri, bileme planı, kaynak teli, baret stok, ilk yardım, yangın tüpü, göz duşu, jeneratör yakıtı, döküntü kiti, gürültü dozu, maske testi, kaza defteri, iş güvenliği toplantısı, risk kaydı, iş izni, enerji kesme, kapalı alan, sıcak iş, yükseklik, elektrik izni, kaldırma planı, kazı kontrolü, makine kontrolü, yorgunluk vardiyası, yalnız çalışan, panik çağrısı, ziyaretçi kaydı, taşeron uygunluk, devriye noktası, kantar fişi",
  crm: "doğum günü notu, sadakat puanı, yönlendirme primi, vip yönlendirme, self servis erteleme, teklif onayı, kapora, tekrarlayan fatura, duygu eğilimi, ayrılma uyarısı, ek satış, şikayet kaydı, sla cezası, garanti portalı, varlık geçmişi, belge klasörü, fiyat kademesi, vergi istisnası, sipariş no, saha tarifi, tehlike etiketi, tercih edilen usta, kara liste, karşılama listesi, sezon duyurusu, bülten, arama kaydı, kaçan arama, toplantı, özet rapor, karar verici, acil kişi ağacı, taşeron puanı, staj takibi, sertifika yenileme, gizlilik sözleşmesi, rekabet yasağı, uyuşmazlık dosyası, tutanak, vekalet, hisse defteri, opsiyon, kredi sözleşmesi, teminat mektubu",
  rapor: "kohort, yaşam boyu değer, edinme maliyeti, geri ödeme süresi, brüt marj, katkı payı, faaliyet kaldıracı, dupont, ekonomik katma değer, nakit döngüsü, stok gün, alacak gün, borç gün, cari oran, asit test, faiz karşılama, borç öz kaynak, aktif kârlılık, öz kaynak kârlılık, varlık devir, sürdürülebilir büyüme, regresyon, mevsim endeksi, hareketli ortalama, üstel düzeltme, senaryo, marjinal analiz, abc maliyet, başabaş duyarlılığı, güvenlik payı, tedarik riski, müşteri yoğunlaşması, bölge çeşitliliği, personel devir maliyeti, eğitim getirisi, devamsızlık, fazla mesai, işgücü verimi, kapasite, darboğaz, ekipman etkinliği, arıza arası süre, onarım süresi, kullanılabilirlik, bakım saati maliyeti, önleyici bakım oranı, yedek devir, atıl stok, depo doluluk, rota sapma maliyeti, yakıt oynaklığı, karbon ayak izi, enerji endeksi, su tüketimi, atık ayrıştırma, uyum riski, denetim bulgusu",
  platform: "anahtar kotası, oauth istemcisi, webhook yeniden deneme, imza doğrulama, kullanım ölçümü, şema kartı, olay akışı, önbellek katmanı, metin arama, imaj sürümü, dağıtım listesi, altyapı betiği, test hattı, sürüm notu üretimi, uçtan uca test, birim test, kapsama, statik denetim, bağımlılık güncelleme, göç geri alma, kanarya, mavi yeşil, yük testi, gerçek kullanıcı ölçümü, hata iletimi, iz sürme, günlük toplama, metrik pano, uptime, durum sayfası, geri bildirim parçacığı, pwa manifest, paylaşım kartı, site haritası, robots, güvenlik dosyası, gizlilik metni, dil dosyası, saat dilimi, birim çevirici, tema değişkeni, beyaz etiket, kiracı ayrımı, satır güvenliği, yavaş sorgu, disk doluluk, sertifika yenileme, dns kaydı, e-posta sağlığı, yedek tatbikatı, denetim paketi, son sıkılaştırma kontrolü",
};

const tail = [
  "kayıt bütünlüğü", "tutar yuvarlama", "boş girdi reddi", "tekrar çalıştırma", "sonuç özeti",
  "Türkçe biçim", "saat dilimi damgası", "yetki reddi", "kota kontrolü", "çevrimdışı yedek",
  "hata mesajı", "ölçü birimi", "eşik uyarısı", "denetim satırı", "dışa aktarma satırı",
  "toplam", "ortalama", "sapma", "medyan", "üst sınır", "alt sınır", "hedef farkı", "trend",
  "eşik aşımı", "kuyruk süresi", "öncelik puanı", "birim maliyet", "adet kontrolü", "saatlik hız",
  "günlük tempo", "haftalık tempo", "aylık tempo", "risk puanı", "güven aralığı", "uç değer",
  "eksik alan", "çift kayıt", "sıra no", "vardiya payı", "bölge payı", "müşteri payı",
  "makine payı", "nakit payı", "veresiye payı", "gecikme payı", "tamamlanma oranı",
];

function titles(module) {
  const extra = extras[module].split(",").map((item) => item.trim()).filter(Boolean);
  const all = [...headlines[module], ...extra, ...tail.map((item) => `${item}`)];
  const unique = [];
  const seen = new Set();
  for (const title of all) {
    const key = title.toLocaleLowerCase("tr");
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(title);
  }
  let extraIndex = 1;
  while (unique.length < 100) {
    const title = `ek ölçü ${extraIndex}`;
    extraIndex += 1;
    if (seen.has(title)) continue;
    seen.add(title);
    unique.push(title);
  }
  return unique.slice(0, 100);
}

const features = [];
for (const [module, start] of modules) {
  titles(module).forEach((title, index) => {
    features.push({ id: start + index, module, title });
  });
}

if (features.length !== 1000) throw new Error(String(features.length));
const ids = new Set(features.map((feature) => feature.id));
if (ids.size !== 1000) throw new Error("mükerrer id");

const body = `import type { EnterpriseFeatureMeta } from "./engine";

export const ENTERPRISE_FEATURES: EnterpriseFeatureMeta[] = ${JSON.stringify(features, null, 2)};
`;
writeFileSync(new URL("../src/enterprise/catalog.ts", import.meta.url), body);
console.log(`catalog ${features.length}`);
